# CHANGELOG
## 2B.3A_PLAYER_FOUNDATION
- PlayItem: logoUrl, seriesTitle, episodeTitle. TMDB movie/series paths pass the TMDB logo; series pass bare name + episode title.
- PlayerHudState: Movie/Series/Live logoUrl; LIVE logo no longer = posterUrl; Series title = bare series name; seasonNumber/episodeNumber/currentEpisodeTitle; displayDescription() (episode > series).
- New: HudBrand/resolveHudBrand (logo XOR title), HudBrandView, PlayerBufferingIndicator.
- PlayerHudOverlay: removed full-screen backdrop/poster AsyncImage and the BUFFERING label. PlayerScreen: buffering indicator under the HUD. LIVE history stores item.logoUrl.
- Tests: logo propagation, brand rules, autoplay/pause regression.
## 2B.3A_LIVE_LOGO_PERSISTENCE
- XtreamCatalogItemEntity.logoUrl (nullable); Channel.toCatalogEntity writes logoUrl = stream_icon (posterUrl kept for compat); titles() maps logoUrl; PlayerHudMigrations (ALTER + LIVE backfill). Manual hunks: Title.kt, TitleListViewModel.playLive, @Database wiring.
## 2B.3B_MOVIE_HUD
- HudComponents (focus-ring buttons, Canvas glyphs, seek bar with played+buffered ranges, D-pad/touch seeking), HudProgressMath, MovieHud (metadata, description expanded when paused, controls, settings button only with a destination). Overlay dispatches Movie.
## 2B.4_SERIES_HUD
- SeriesHud + EpisodeThumbnailRow; PlaybackSession.episodeKeys/jumpToEpisode; PlayerViewModel.playEpisode; PlayerUiState.queuedEpisodes; shared HudTransportControls.
## 2B.5_LIVE_HUD
- LiveHud (two distinct progress bars), LiveHudModel (timing, clock, capabilities, tiles), LiveHudDestinations; EPG description honours profile liveTvHudShowEpgDescription; legacy layout reduced to PlayerHudContent.Other.
## STAGE_3_RESPONSIVENESS
- HudLayoutSpec, HudAutoHidePolicy, HudKeys, PlayerHudSettings, PlayerPreferencesPanel; overlay shell: configurable auto-hide, remote wake + focus restoration, double-tap seek, touch lock, Back closes panel; per-profile columns hudAutoHideSeconds, hudKeepVisibleWhenPaused, tapSeekEnabled, tapSeekSeconds (+sanitizer, defaults, migration); PlayerViewModel.updateHudSettings.
