# MANUAL_CHANGES_REQUIRED.md  (files that were NOT in the supplied bundle)

The following files were described but are not in the ZIP, so they could not be edited or verified.
Patch `2B.3A_LIVE_LOGO_PERSISTENCE` + these hunks form ONE atomic unit (Room schema + domain model + LIVE entry).
Apply them together; applying the patch alone does not compile (Title.logoUrl missing) and bumping nothing crashes Room.

## 1. app/src/main/java/app/vireo/domain/model/Title.kt
Add a defaulted property at the END of the constructor (source compatible with all existing callers):
    val logoUrl: String? = null,
Semantics: LIVE = channel logo (Xtream stream_icon). Movies/series: null. `posterUrl` is unchanged.

## 2. app/src/main/java/app/vireo/ui/list/TitleListViewModel.kt  (playLive)
Where the LIVE PlayItem is created, add one argument:
    logoUrl = title.logoUrl,
(`title.name`, `repo.liveUrl(title.id)`, epgChannelId, streamId, sourceId stay as they are.)

## 3. The @Database class (file not supplied; name unknown)
- Bump `version` from N to N+1.
- Register: `.addMigrations(PlayerHudMigrations.create(from = N, to = N + 1))`
  (`PlayerHudMigrations` is added by the patch; it adds `xtream_catalog_items.logoUrl`, backfills it from
  `posterUrl` for LIVE rows, and - after STAGE_3 - adds four `profile_settings` columns).
- Do NOT use destructive fallback. If schemas are exported (exportSchema = true) regenerate/commit the new JSON.
- If you apply STAGE_3 later in a separate release, split `STATEMENTS` into two migrations (N->N+1, N+1->N+2).

## 4. Other readers of Title.posterUrl for LIVE
`Channel.toCatalogEntity()` still writes `posterUrl = iconUrl` (compat) AND `logoUrl = iconUrl`.
Unseen LIVE list screens may still read posterUrl for channel icons; once they use logoUrl, drop the posterUrl line.

## 5. Navigation destinations (optional, LIVE tiles)
`PlayerScreen(..., liveDestinations = LiveHudDestinations(onOpenTvGuide, onOpenHistory, onSelectRecentChannel))`
must be supplied by the NavHost (not in bundle). Until then those tiles are hidden - no fake actions.
Selecting a recent channel needs the same Title->PlayItem path as TitleListViewModel.playLive.
