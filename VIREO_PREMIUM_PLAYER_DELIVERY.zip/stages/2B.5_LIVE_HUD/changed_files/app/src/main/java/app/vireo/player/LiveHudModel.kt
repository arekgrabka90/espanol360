package app.vireo.player

import app.vireo.domain.model.EpgProgram
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * Timing of the programme that is on air, derived only from real EPG data.
 * Pure Kotlin so it can be unit-tested.
 */
internal data class LiveProgramTiming(
    val startMs: Long,
    val endMs: Long,
    val elapsedMs: Long,
    val remainingMs: Long,
    val fraction: Float,
)

/**
 * Null when there is no programme, its time range is invalid, or it has not
 * started yet. A stale programme (end already passed, e.g. between EPG refreshes)
 * is shown as completed rather than extrapolated.
 */
internal fun liveProgramTiming(program: EpgProgram?, nowMs: Long): LiveProgramTiming? {
    if (program == null || !program.hasValidTimeRange) return null
    if (nowMs < program.startTimeMs) return null

    val total = program.endTimeMs - program.startTimeMs
    val elapsed = (nowMs - program.startTimeMs).coerceIn(0L, total)

    return LiveProgramTiming(
        startMs = program.startTimeMs,
        endMs = program.endTimeMs,
        elapsedMs = elapsed,
        remainingMs = total - elapsed,
        fraction = elapsed.toFloat() / total,
    )
}

/** "20:05" in the given zone (24-hour clock). */
internal fun formatClockTime(
    epochMs: Long,
    zone: TimeZone = TimeZone.getDefault(),
    locale: Locale = Locale.getDefault(),
): String = SimpleDateFormat("HH:mm", locale).apply { timeZone = zone }.format(epochMs)

/** "25 min left", "1 h 05 min left", "< 1 min left". */
internal fun formatRemaining(remainingMs: Long): String {
    val minutes = (remainingMs.coerceAtLeast(0L) + 59_999L) / 60_000L

    return when {
        remainingMs <= 0L -> "Ending"
        minutes < 1L -> "< 1 min left"
        minutes < 60L -> "$minutes min left"
        else -> "${minutes / 60L} h ${(minutes % 60L).toString().padStart(2, '0')} min left"
    }
}

/**
 * The left area shows the channel logo OR its name. The channel name only
 * appears again in the information area when the left area shows a logo, so the
 * name is never displayed twice.
 */
internal fun liveShowsChannelNameInInfo(brand: HudBrand): Boolean = brand is HudBrand.Logo

/** What the engine can honestly do for the current LIVE stream. */
internal data class LiveControlCapabilities(
    val showSeek: Boolean,
    val showChannelPrevious: Boolean,
    val showChannelNext: Boolean,
)

/**
 * Ordinary VOD seeking is only offered when the engine reports the current
 * item as seekable with a known window (for example HLS with a DVR window).
 */
internal fun liveControlCapabilities(
    progress: PlayerProgressState,
    hasPrevious: Boolean,
    hasNext: Boolean,
): LiveControlCapabilities = LiveControlCapabilities(
    showSeek = progress.isSeekable && progress.durationMs > 0L,
    showChannelPrevious = hasPrevious,
    showChannelNext = hasNext,
)

/** Destinations the host app can provide. Null = not implemented, tile is hidden. */
class LiveHudDestinations(
    val onOpenTvGuide: (() -> Unit)? = null,
    val onOpenHistory: (() -> Unit)? = null,
    val onSelectRecentChannel: ((RecentLiveChannel) -> Unit)? = null,
)

internal sealed interface LiveTile {
    data object TvGuide : LiveTile
    data object History : LiveTile
    data class Recent(val channel: RecentLiveChannel) : LiveTile
}

/**
 * Bottom tile row. TV Guide and History appear only when a real destination
 * exists. Recent channels come from the stored history, newest first, without
 * the channel that is playing now.
 */
internal fun liveTiles(
    content: PlayerHudContent.Live,
    destinations: LiveHudDestinations,
    maxRecent: Int = 8,
): List<LiveTile> = buildList {
    if (destinations.onOpenTvGuide != null) add(LiveTile.TvGuide)
    if (destinations.onOpenHistory != null) add(LiveTile.History)

    content.recentChannels
        .asSequence()
        .filterNot { !content.streamId.isNullOrBlank() && it.streamId == content.streamId }
        .sortedByDescending { it.lastPlayedAt }
        .take(maxRecent)
        .forEach { add(LiveTile.Recent(it)) }
}
