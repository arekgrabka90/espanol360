package app.vireo.player

import app.vireo.domain.model.EpgNowNext
import app.vireo.domain.model.EpgProgram
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Locale
import java.util.TimeZone

class LiveHudModelTest {

    private fun program(start: Long, end: Long, title: String = "Show") = EpgProgram(
        channelId = "c",
        title = title,
        startTimeMs = start,
        endTimeMs = end,
    )

    private fun live(
        recents: List<RecentLiveChannel> = emptyList(),
        streamId: String? = "10",
        logoUrl: String? = null,
    ) = buildPlayerHudState(
        PlayerUiState(
            item = PlayItem(
                title = "Channel",
                url = "u",
                contentType = "LIVE",
                streamId = streamId,
                logoUrl = logoUrl,
            )
        ),
        EpgNowNext(null, null),
        recents,
    ).content as PlayerHudContent.Live

    private fun recent(id: String, at: Long) = RecentLiveChannel(
        sourceId = 1L, streamId = id, channelName = "Ch $id",
        epgChannelId = null, logoUrl = null, lastPlayedAt = at,
    )

    @Test
    fun `timing reflects elapsed and remaining time`() {
        val t = liveProgramTiming(program(1_000_000L, 1_000_000L + 3_600_000L), 1_000_000L + 900_000L)!!

        assertEquals(900_000L, t.elapsedMs)
        assertEquals(2_700_000L, t.remainingMs)
        assertEquals(0.25f, t.fraction, 0.0001f)
    }

    @Test
    fun `no programme or invalid range gives no timing`() {
        assertNull(liveProgramTiming(null, 5L))
        assertNull(liveProgramTiming(program(100L, 100L), 100L))
        assertNull(liveProgramTiming(program(200L, 100L), 150L))
    }

    @Test
    fun `programme that has not started gives no timing`() {
        assertNull(liveProgramTiming(program(1_000L, 2_000L), 999L))
    }

    @Test
    fun `stale programme is completed not extrapolated`() {
        val t = liveProgramTiming(program(1_000L, 2_000L), 9_000L)!!

        assertEquals(1f, t.fraction, 0f)
        assertEquals(0L, t.remainingMs)
    }

    @Test
    fun `remaining time wording`() {
        assertEquals("Ending", formatRemaining(0L))
        assertEquals("1 min left", formatRemaining(30_000L))
        assertEquals("25 min left", formatRemaining(25 * 60_000L))
        assertEquals("1 h 05 min left", formatRemaining(65 * 60_000L))
    }

    @Test
    fun `clock time uses the given zone`() {
        val utc = TimeZone.getTimeZone("UTC")

        assertEquals("20:05", formatClockTime(72_300_000L, utc, Locale.US))
        assertEquals(
            "21:05",
            formatClockTime(72_300_000L, TimeZone.getTimeZone("GMT+1"), Locale.US),
        )
    }

    @Test
    fun `live HUD carries the channel logo only from logoUrl`() {
        assertEquals("https://img/c.png", live(logoUrl = "https://img/c.png").logoUrl)
        assertNull(live().logoUrl)
    }

    @Test
    fun `channel name is shown in info only when the left area shows a logo`() {
        assertTrue(liveShowsChannelNameInInfo(live(logoUrl = "l").brand()))
        assertFalse(liveShowsChannelNameInInfo(live().brand()))
    }

    @Test
    fun `seek controls need a seekable stream with a known window`() {
        val seekable = PlayerProgressState(1_000L, 60_000L, 5_000L, isSeekable = true)
        val plain = PlayerProgressState(1_000L, 0L, 0L, isSeekable = false)
        val seekableNoWindow = PlayerProgressState(1_000L, 0L, 0L, isSeekable = true)

        assertTrue(liveControlCapabilities(seekable, false, false).showSeek)
        assertFalse(liveControlCapabilities(plain, false, false).showSeek)
        assertFalse(liveControlCapabilities(seekableNoWindow, false, false).showSeek)
    }

    @Test
    fun `channel navigation mirrors the queue`() {
        val caps = liveControlCapabilities(PlayerProgressState(), hasPrevious = true, hasNext = false)

        assertTrue(caps.showChannelPrevious)
        assertFalse(caps.showChannelNext)
    }

    @Test
    fun `tv guide and history tiles need real destinations`() {
        val none = liveTiles(live(), LiveHudDestinations())
        val both = liveTiles(
            live(),
            LiveHudDestinations(onOpenTvGuide = {}, onOpenHistory = {}),
        )

        assertTrue(none.isEmpty())
        assertEquals(listOf(LiveTile.TvGuide, LiveTile.History), both)
    }

    @Test
    fun `recent channels are newest first and exclude the current channel`() {
        val content = live(
            recents = listOf(recent("1", 100L), recent("10", 500L), recent("2", 300L)),
            streamId = "10",
        )

        val tiles = liveTiles(content, LiveHudDestinations())

        assertEquals(
            listOf("2", "1"),
            tiles.map { (it as LiveTile.Recent).channel.streamId },
        )
    }

    @Test
    fun `recent tiles are capped`() {
        val content = live(recents = (1..20).map { recent("x$it", it.toLong()) })

        assertEquals(3, liveTiles(content, LiveHudDestinations(), maxRecent = 3).size)
    }
}
