# 2B.5_LIVE_HUD

LIVE HUD with two distinct progress bars, capability-based controls, tiles.

**Depends on:** 2B.4_SERIES_HUD (2B.3A_LIVE_LOGO_PERSISTENCE for real channel logos)

**Apply:** from the VIREO repo root `patch -p1 < patch.diff` (patches are sequential, in the order listed in IMPLEMENTATION_REPORT.md), or copy `changed_files/` over the repo (complete files; each stage's files are the state AFTER that stage).

**Files:** see FILES.txt. **Not executed:** build and tests (see TEST_REPORT.md).
