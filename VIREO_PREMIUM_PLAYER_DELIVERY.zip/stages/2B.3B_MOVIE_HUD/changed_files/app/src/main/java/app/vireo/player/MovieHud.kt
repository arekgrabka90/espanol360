package app.vireo.player

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Which optional metadata the movie HUD shows. Everything defaults to on. */
data class MovieHudMetadata(
    val showYear: Boolean = true,
    val showGenre: Boolean = true,
    val showDuration: Boolean = true,
    val showRating: Boolean = true,
    val showDescription: Boolean = true,
)

/**
 * Metadata line for a movie: only values that really exist, in a fixed order.
 * Never produces placeholders for missing data.
 */
internal fun movieMetadataParts(
    content: PlayerHudContent.Movie,
    options: MovieHudMetadata = MovieHudMetadata(),
): List<String> = listOfNotNull(
    content.year?.trim()?.takeIf { options.showYear && it.isNotEmpty() },
    content.genre?.trim()?.takeIf { options.showGenre && it.isNotEmpty() },
    content.duration?.trim()?.takeIf { options.showDuration && it.isNotEmpty() },
    content.rating?.trim()?.takeIf { options.showRating && it.isNotEmpty() }?.let { "★ $it" },
)

internal fun movieDescription(
    content: PlayerHudContent.Movie,
    options: MovieHudMetadata = MovieHudMetadata(),
): String? =
    if (options.showDescription) {
        content.description?.trim()?.takeIf { it.isNotEmpty() }
    } else {
        null
    }

/**
 * Movie HUD: transparent layer over the real video.
 * Top-left: logo or title. Bottom: metadata, description (expanded while
 * paused), progress, transport controls and preferences. No episode or LIVE
 * elements belong here.
 */
@Composable
internal fun MovieHud(
    content: PlayerHudContent.Movie,
    hudState: PlayerHudState,
    progress: PlayerProgressState,
    actions: HudActions,
    interaction: HudInteraction,
    layout: HudLayoutMetrics,
    metadata: MovieHudMetadata = MovieHudMetadata(),
) {
    Box(modifier = Modifier.fillMaxSize()) {
        HudEdgeScrim(top = true, height = if (layout.wide) 170.dp else 120.dp)
        HudEdgeScrim(top = false, height = if (layout.wide) 340.dp else 260.dp)

        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .fillMaxWidth()
                .padding(horizontal = layout.horizontalPadding, vertical = layout.topPadding),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            HudButton(
                onClick = { interaction.onInteract(); actions.onBack() },
                description = "Back",
                onFocusChange = interaction.onFocusChange,
            ) {
                Icon(Icons.Default.Close, contentDescription = null, tint = Color.White)
            }
            Spacer(Modifier.width(18.dp))
            HudBrandView(
                brand = content.brand(),
                titleSize = if (layout.wide) 26.sp else 20.sp,
            )
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = layout.horizontalPadding)
                .padding(bottom = layout.bottomPadding),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            MovieInfo(
                content = content,
                expanded = !hudState.isPlaying,
                options = metadata,
                wide = layout.wide,
            )

            HudProgressRow(
                progress = progress,
                interaction = interaction,
                onSeekTo = actions.onSeekTo,
            )

            HudTransportControls(
                hudState = hudState,
                progress = progress,
                actions = actions,
                interaction = interaction,
                wide = layout.wide,
            )
        }
    }
}

@Composable
private fun MovieInfo(
    content: PlayerHudContent.Movie,
    expanded: Boolean,
    options: MovieHudMetadata,
    wide: Boolean,
) {
    val parts = movieMetadataParts(content, options)
    val description = movieDescription(content, options)

    if (parts.isEmpty() && description == null) return

    Column(
        modifier = Modifier
            .fillMaxWidth(if (wide) 0.62f else 0.94f)
            .animateContentSize(),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        if (parts.isNotEmpty()) {
            Text(
                parts.joinToString("   ·   "),
                color = Color.White.copy(alpha = 0.74f),
                style = MaterialTheme.typography.labelMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (description != null) {
            Text(
                description,
                color = Color.White.copy(alpha = 0.86f),
                style = MaterialTheme.typography.bodyMedium,
                maxLines = if (expanded) 6 else 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}
