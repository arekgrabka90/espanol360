package app.vireo.player

/**
 * Pure helpers behind the HUD progress bar(s). No Compose, no Media3, so the
 * arithmetic is unit-testable.
 */
internal data class ProgressFractions(
    val played: Float,
    val buffered: Float,
)

/**
 * Fractions (0..1) of the actual playback position and buffered range.
 * Buffered is never smaller than played. Unknown duration yields zeros:
 * the bar never invents progress.
 */
internal fun progressFractions(
    positionMs: Long,
    durationMs: Long,
    bufferedPositionMs: Long,
): ProgressFractions {
    if (durationMs <= 0L) return ProgressFractions(0f, 0f)

    val played = positionMs.coerceIn(0L, durationMs).toFloat() / durationMs
    val buffered = bufferedPositionMs.coerceIn(0L, durationMs).toFloat() / durationMs

    return ProgressFractions(
        played = played,
        buffered = maxOf(played, buffered),
    )
}

internal fun positionForFraction(fraction: Float, durationMs: Long): Long {
    if (durationMs <= 0L || fraction.isNaN()) return 0L
    return (fraction.coerceIn(0f, 1f) * durationMs).toLong()
}

internal fun steppedPosition(
    positionMs: Long,
    durationMs: Long,
    deltaMs: Long,
): Long {
    val target = positionMs + deltaMs
    return if (durationMs > 0L) target.coerceIn(0L, durationMs) else target.coerceAtLeast(0L)
}

/** "m:ss" or "h:mm:ss". */
internal fun formatHudTime(valueMs: Long): String {
    val seconds = valueMs.coerceAtLeast(0L) / 1_000L
    val hours = seconds / 3_600L
    val minutes = (seconds % 3_600L) / 60L
    val remaining = seconds % 60L

    return if (hours > 0L) {
        "%d:%02d:%02d".format(hours, minutes, remaining)
    } else {
        "%d:%02d".format(minutes, remaining)
    }
}
