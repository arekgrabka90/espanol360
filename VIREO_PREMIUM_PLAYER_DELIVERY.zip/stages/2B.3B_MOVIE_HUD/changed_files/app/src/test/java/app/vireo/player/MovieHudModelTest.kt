package app.vireo.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MovieHudModelTest {

    private fun movie(
        year: String? = "2026",
        genre: String? = "Drama",
        duration: String? = "120 min",
        rating: String? = "8.1",
        description: String? = "Plot.",
    ) = PlayerHudContent.Movie(
        title = "Movie",
        description = description,
        year = year,
        genre = genre,
        duration = duration,
        rating = rating,
        posterUrl = "poster",
        backdropUrl = "backdrop",
    )

    @Test
    fun `metadata line keeps a fixed order`() {
        assertEquals(
            listOf("2026", "Drama", "120 min", "★ 8.1"),
            movieMetadataParts(movie()),
        )
    }

    @Test
    fun `missing and blank metadata is omitted without placeholders`() {
        val parts = movieMetadataParts(
            movie(year = null, genre = "  ", duration = "", rating = "7.0")
        )

        assertEquals(listOf("★ 7.0"), parts)
    }

    @Test
    fun `no metadata at all gives an empty line`() {
        val parts = movieMetadataParts(movie(null, null, null, null, null))

        assertTrue(parts.isEmpty())
        assertNull(movieDescription(movie(description = null)))
    }

    @Test
    fun `visibility options hide individual items`() {
        val options = MovieHudMetadata(showGenre = false, showRating = false)

        assertEquals(
            listOf("2026", "120 min"),
            movieMetadataParts(movie(), options),
        )
    }

    @Test
    fun `description can be hidden and blank description is absent`() {
        assertNull(movieDescription(movie(), MovieHudMetadata(showDescription = false)))
        assertNull(movieDescription(movie(description = "   ")))
        assertEquals("Plot.", movieDescription(movie()))
    }
}
