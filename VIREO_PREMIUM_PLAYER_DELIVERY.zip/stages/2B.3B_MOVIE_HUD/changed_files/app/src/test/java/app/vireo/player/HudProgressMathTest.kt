package app.vireo.player

import org.junit.Assert.assertEquals
import org.junit.Test

class HudProgressMathTest {

    @Test
    fun `fractions reflect real position and buffer`() {
        val f = progressFractions(positionMs = 25_000L, durationMs = 100_000L, bufferedPositionMs = 60_000L)

        assertEquals(0.25f, f.played, 0.0001f)
        assertEquals(0.60f, f.buffered, 0.0001f)
    }

    @Test
    fun `buffer is never behind the playhead`() {
        val f = progressFractions(50_000L, 100_000L, 10_000L)

        assertEquals(0.5f, f.buffered, 0.0001f)
    }

    @Test
    fun `unknown duration yields no progress instead of invented progress`() {
        val f = progressFractions(5_000L, 0L, 9_000L)

        assertEquals(0f, f.played, 0f)
        assertEquals(0f, f.buffered, 0f)
    }

    @Test
    fun `out of range values are clamped`() {
        val f = progressFractions(-5L, 1_000L, 5_000L)
        val g = progressFractions(9_000L, 1_000L, 9_000L)

        assertEquals(0f, f.played, 0f)
        assertEquals(1f, f.buffered, 0f)
        assertEquals(1f, g.played, 0f)
    }

    @Test
    fun `fraction maps back to a position within the duration`() {
        assertEquals(50_000L, positionForFraction(0.5f, 100_000L))
        assertEquals(100_000L, positionForFraction(1.7f, 100_000L))
        assertEquals(0L, positionForFraction(-1f, 100_000L))
        assertEquals(0L, positionForFraction(Float.NaN, 100_000L))
        assertEquals(0L, positionForFraction(0.5f, 0L))
    }

    @Test
    fun `stepped seeking stays inside the media`() {
        assertEquals(0L, steppedPosition(4_000L, 100_000L, -10_000L))
        assertEquals(100_000L, steppedPosition(95_000L, 100_000L, 10_000L))
        assertEquals(24_000L, steppedPosition(14_000L, 100_000L, 10_000L))
        assertEquals(20_000L, steppedPosition(10_000L, 0L, 10_000L))
    }

    @Test
    fun `time formatting handles minutes and hours`() {
        assertEquals("0:00", formatHudTime(-1L))
        assertEquals("1:05", formatHudTime(65_000L))
        assertEquals("1:02:03", formatHudTime(3_723_000L))
    }

    @Test
    fun `engine progress normalisation feeds the bar consistently`() {
        val p = normalizePlayerProgress(
            positionMs = 120_000L,
            durationMs = 100_000L,
            bufferedPositionMs = 300_000L,
            isSeekable = true,
        )
        val f = progressFractions(p.positionMs, p.durationMs, p.bufferedPositionMs)

        assertEquals(1f, f.played, 0f)
        assertEquals(1f, f.buffered, 0f)
    }
}
