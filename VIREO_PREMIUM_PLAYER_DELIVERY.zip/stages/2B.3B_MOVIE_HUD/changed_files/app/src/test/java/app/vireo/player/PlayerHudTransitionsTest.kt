package app.vireo.player

import app.vireo.domain.model.EpgNowNext
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PlayerHudTransitionsTest {

    private val item = PlayItem(title = "M", url = "u", contentType = "MOVIE")

    private fun hud(runtime: PlayerRuntimeState, hasPrev: Boolean = false, hasNext: Boolean = false) =
        buildPlayerHudState(
            PlayerUiState(
                item = item,
                runtime = runtime.copy(hasPrevious = hasPrev, hasNext = hasNext),
            ),
            EpgNowNext(null, null),
            emptyList(),
        )

    @Test
    fun `transport and playing flags are passed through`() {
        val buffering = hud(PlayerRuntimeState(transportState = PlayerTransportState.BUFFERING))
        val playing = hud(
            PlayerRuntimeState(transportState = PlayerTransportState.READY, isPlaying = true)
        )

        assertEquals(PlayerTransportState.BUFFERING, buffering.transportState)
        assertFalse(buffering.isPlaying)
        assertTrue(playing.isPlaying)
    }

    @Test
    fun `previous and next only reflect the queue`() {
        val single = hud(PlayerRuntimeState())
        val middle = hud(PlayerRuntimeState(), hasPrev = true, hasNext = true)

        assertFalse(single.hasPrevious)
        assertFalse(single.hasNext)
        assertTrue(middle.hasPrevious)
        assertTrue(middle.hasNext)
    }

    @Test
    fun `error message is exposed and absent otherwise`() {
        assertNull(hud(PlayerRuntimeState()).errorMessage)
        assertEquals(
            "boom",
            hud(PlayerRuntimeState(errorMessage = "boom")).errorMessage,
        )
    }

    @Test
    fun `no item yields empty Other content with no brand`() {
        val state = buildPlayerHudState(PlayerUiState(), EpgNowNext(null, null), emptyList())

        assertEquals(HudBrand.None, state.content.brand())
    }
}
