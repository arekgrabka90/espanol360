package app.vireo.player

/** Form factors the HUD has dedicated layouts for. */
enum class HudFormFactor { PhonePortrait, PhoneLandscape, Tablet, Tv }

/**
 * Pure layout decisions (dp values as Int) so they can be unit-tested; the
 * composables only convert them to Dp. Shared state stays independent of Compose.
 */
data class HudLayoutSpec(
    val formFactor: HudFormFactor,
    val horizontalPaddingDp: Int,
    val topPaddingDp: Int,
    val bottomPaddingDp: Int,
    /** Short screens (landscape phones): fewer lines, smaller cards. */
    val compactHeight: Boolean,
    val episodeCardWidthDp: Int,
    val primaryButtonDp: Int,
    val titleSizeSp: Int,
    val descriptionMaxLines: Int,
    /** Wide screens place information beside the logo and use wider text blocks. */
    val wide: Boolean,
)

fun hudLayoutSpec(widthDp: Int, heightDp: Int, isTv: Boolean): HudLayoutSpec {
    val form = when {
        isTv -> HudFormFactor.Tv
        widthDp >= 840 && heightDp >= 600 -> HudFormFactor.Tablet
        heightDp > widthDp -> HudFormFactor.PhonePortrait
        else -> HudFormFactor.PhoneLandscape
    }
    val compact = heightDp < 500

    return when (form) {
        HudFormFactor.Tv -> HudLayoutSpec(
            form, 56, 38, 40, compact, 200, 68, 28, 3, wide = true,
        )
        HudFormFactor.Tablet -> HudLayoutSpec(
            form, 48, 32, 32, compact, 176, 64, 26, 3, wide = true,
        )
        HudFormFactor.PhoneLandscape -> HudLayoutSpec(
            form, 28, 14, 12, compact, 116, 52, 20, 2, wide = widthDp >= 850,
        )
        HudFormFactor.PhonePortrait -> HudLayoutSpec(
            form, 20, 20, 20, compact = false, 132, 56, 20, 3, wide = false,
        )
    }
}
