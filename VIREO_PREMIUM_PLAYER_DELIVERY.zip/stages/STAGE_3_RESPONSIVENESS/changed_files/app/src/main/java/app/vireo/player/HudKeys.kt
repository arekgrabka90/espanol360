package app.vireo.player

/** Remote/keyboard keys the HUD reacts to, independent of Compose key types. */
enum class HudKey { Up, Down, Left, Right, Center, PlayPause, Play, Pause, FastForward, Rewind, Other }

enum class HudKeyAction { None, WakeHud, TogglePlayback, Play, Pause, SeekForward, SeekBackward }

/**
 * What a key does. Media keys always act. Directional keys and Center only wake
 * a hidden HUD (the key is consumed so it does not also move focus blindly);
 * while the HUD is visible they are left to normal focus navigation.
 */
fun hudKeyAction(key: HudKey, hudVisible: Boolean): HudKeyAction = when (key) {
    HudKey.PlayPause -> HudKeyAction.TogglePlayback
    HudKey.Play -> HudKeyAction.Play
    HudKey.Pause -> HudKeyAction.Pause
    HudKey.FastForward -> HudKeyAction.SeekForward
    HudKey.Rewind -> HudKeyAction.SeekBackward
    HudKey.Up, HudKey.Down, HudKey.Left, HudKey.Right, HudKey.Center ->
        if (hudVisible) HudKeyAction.None else HudKeyAction.WakeHud
    HudKey.Other -> HudKeyAction.None
}

/** Which video third a tap landed in: left, middle or right. */
enum class TapZone { Left, Middle, Right }

fun tapZone(xPx: Float, widthPx: Float): TapZone {
    if (widthPx <= 0f) return TapZone.Middle
    val f = xPx / widthPx
    return when {
        f < 0.33f -> TapZone.Left
        f > 0.67f -> TapZone.Right
        else -> TapZone.Middle
    }
}

/** Signed seek delta for a double-tap, or null when the tap is not a seek. */
fun doubleTapSeekDeltaMs(zone: TapZone, enabled: Boolean, seconds: Int, seekable: Boolean): Long? {
    if (!enabled || !seekable) return null
    return when (zone) {
        TapZone.Left -> -seconds * 1_000L
        TapZone.Right -> seconds * 1_000L
        TapZone.Middle -> null
    }
}
