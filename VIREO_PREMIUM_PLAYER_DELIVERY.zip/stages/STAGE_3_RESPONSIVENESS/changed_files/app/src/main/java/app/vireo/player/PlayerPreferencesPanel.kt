package app.vireo.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp

/**
 * Real, persisted player preferences (per profile). Focus moves to the first row
 * when the panel opens; the caller restores focus to the settings button when it
 * closes. Touch lock is a session action, not a stored preference.
 */
@Composable
internal fun PlayerPreferencesPanel(
    settings: PlayerHudSettings,
    onChange: (PlayerHudSettings) -> Unit,
    onLockTouch: () -> Unit,
    onClose: () -> Unit,
    interaction: HudInteraction,
    modifier: Modifier = Modifier,
) {
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }

    // Scrim: tapping outside closes the panel. Transparent, video stays visible.
    Box(
        modifier = modifier
            .fillMaxSize()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClose,
            ),
    )

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.BottomEnd) {
        Column(
            modifier = Modifier
                .padding(24.dp)
                .width(340.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xE6141416))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {},
                )
                .padding(vertical = 8.dp),
        ) {
            PanelRow(
                "HUD auto-hide",
                autoHideLabel(settings.autoHideSeconds),
                interaction,
                Modifier.focusRequester(first),
            ) { onChange(settings.copy(autoHideSeconds = nextAutoHideSeconds(settings.autoHideSeconds))) }

            PanelRow(
                "Keep HUD visible when paused",
                if (settings.keepVisibleWhenPaused) "On" else "Off",
                interaction,
            ) { onChange(settings.copy(keepVisibleWhenPaused = !settings.keepVisibleWhenPaused)) }

            if (!settings.isTv) {
                PanelRow(
                    "Double-tap to seek",
                    if (settings.tapSeekEnabled) "On" else "Off",
                    interaction,
                ) { onChange(settings.copy(tapSeekEnabled = !settings.tapSeekEnabled)) }

                PanelRow(
                    "Double-tap seek step",
                    "${settings.tapSeekSeconds} s",
                    interaction,
                ) { onChange(settings.copy(tapSeekSeconds = nextTapSeekSeconds(settings.tapSeekSeconds))) }

                PanelRow("Lock touch", "Long-press to unlock", interaction, onClick = onLockTouch)
            }

            PanelRow("Close", "", interaction, onClick = onClose)
        }
    }
}

@Composable
private fun PanelRow(
    label: String,
    value: String,
    interaction: HudInteraction,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (focused) Color.White.copy(alpha = 0.22f) else Color.Transparent)
            .onFocusChanged {
                focused = it.isFocused
                interaction.onFocusChange(it.isFocused)
            }
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                role = Role.Button,
                onClick = { interaction.onInteract(); onClick() },
            )
            .padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = Color.White, style = MaterialTheme.typography.bodyMedium)
        if (value.isNotEmpty()) {
            Text(value, color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.labelMedium)
        }
    }
}
