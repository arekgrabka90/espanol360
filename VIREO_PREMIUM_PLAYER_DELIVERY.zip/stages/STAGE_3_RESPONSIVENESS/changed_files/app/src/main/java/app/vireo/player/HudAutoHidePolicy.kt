package app.vireo.player

/** Allowed auto-hide choices in seconds; 0 means "off". */
val HUD_AUTO_HIDE_OPTIONS_SECONDS: List<Int> = listOf(3, 5, 8, 10, 0)

/**
 * Default is 8 seconds: long enough for remote-control users to read and move
 * focus, short enough not to linger. (Previously hard-coded to 6 s.)
 */
const val HUD_AUTO_HIDE_DEFAULT_SECONDS: Int = 8

/** Next value when cycling the option in the preferences panel. */
fun nextAutoHideSeconds(current: Int): Int {
    val i = HUD_AUTO_HIDE_OPTIONS_SECONDS.indexOf(current)
    return HUD_AUTO_HIDE_OPTIONS_SECONDS[(i + 1).mod(HUD_AUTO_HIDE_OPTIONS_SECONDS.size)]
}

/**
 * Delay before the HUD hides, or null when it must stay visible.
 * It never hides while a control has focus, a panel is open, or - depending on
 * the profile setting - while paused.
 */
internal fun hudHideDelayMs(
    autoHideSeconds: Int,
    isPlaying: Boolean,
    keepVisibleWhenPaused: Boolean,
    hasFocusedControl: Boolean,
    panelOpen: Boolean,
): Long? = when {
    autoHideSeconds <= 0 -> null
    panelOpen || hasFocusedControl -> null
    !isPlaying && keepVisibleWhenPaused -> null
    else -> autoHideSeconds * 1_000L
}
