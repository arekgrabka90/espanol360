package app.vireo.data.local

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Schema changes required by the Premium Player work.
 *
 * The @Database class is not part of the supplied source bundle, so the
 * database version and the `addMigrations(...)` call must be wired by hand:
 *
 *   .addMigrations(PlayerHudMigrations.create(from = N, to = N + 1))
 *
 * where N is the current @Database version, and `version` is bumped to N + 1.
 * See docs/MANUAL_CHANGES_REQUIRED.md.
 */
object PlayerHudMigrations {

    /** Statements are exposed so they can be reviewed and unit-tested. */
    val STATEMENTS: List<String> = listOf(
        // Xtream catalog: separate channel logo column.
        "ALTER TABLE xtream_catalog_items ADD COLUMN logoUrl TEXT DEFAULT NULL",
        // Backfill: until now LIVE rows stored stream_icon in posterUrl.
        "UPDATE xtream_catalog_items SET logoUrl = posterUrl " +
            "WHERE contentType = 'LIVE' AND posterUrl IS NOT NULL AND TRIM(posterUrl) <> ''",
        // Player preferences, per profile (see ProfileSettingsEntity).
        "ALTER TABLE profile_settings ADD COLUMN hudAutoHideSeconds INTEGER NOT NULL DEFAULT 8",
        "ALTER TABLE profile_settings ADD COLUMN hudKeepVisibleWhenPaused INTEGER NOT NULL DEFAULT 1",
        "ALTER TABLE profile_settings ADD COLUMN tapSeekEnabled INTEGER NOT NULL DEFAULT 1",
        "ALTER TABLE profile_settings ADD COLUMN tapSeekSeconds INTEGER NOT NULL DEFAULT 10",
    )

    fun create(from: Int, to: Int): Migration = object : Migration(from, to) {
        override fun migrate(db: SupportSQLiteDatabase) {
            STATEMENTS.forEach { db.execSQL(it) }
        }
    }
}
