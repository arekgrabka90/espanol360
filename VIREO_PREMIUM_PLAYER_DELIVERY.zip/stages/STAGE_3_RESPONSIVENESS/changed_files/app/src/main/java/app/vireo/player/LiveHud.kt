package app.vireo.player

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/**
 * LIVE HUD: transparent layer over the real stream.
 *
 * Left: channel logo or name. Main information: programme title, start/end
 * times, remaining time, a SMALL programme bar, channel name (only when the left
 * area shows a logo), EPG description and the next programme. Below it, a
 * separate WIDE programme bar. Then LIVE-specific controls and the bottom tiles.
 *
 * The two bars show the same programme timeline for different purposes and are
 * intentionally independent composables. Technical quality (resolution, codec,
 * ...) is not shown: VIREO has no verified source for it yet.
 */
@Composable
internal fun LiveHud(
    content: PlayerHudContent.Live,
    hudState: PlayerHudState,
    progress: PlayerProgressState,
    actions: HudActions,
    interaction: HudInteraction,
    layout: HudLayoutMetrics,
    destinations: LiveHudDestinations,
    showEpgDescription: Boolean,
) {
    val nowMs = rememberNowMs()
    val timing = liveProgramTiming(content.currentProgram, nowMs)
    val brand = content.brand()

    Box(modifier = Modifier.fillMaxSize()) {
        HudEdgeScrim(top = true, height = if (layout.wide) 150.dp else 110.dp)
        HudEdgeScrim(top = false, height = if (layout.wide) 460.dp else 340.dp)

        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .fillMaxWidth()
                .padding(horizontal = layout.horizontalPadding, vertical = layout.topPadding),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            HudButton(
                onClick = { interaction.onInteract(); actions.onBack() },
                description = "Back",
                onFocusChange = interaction.onFocusChange,
            ) {
                Icon(Icons.Default.Close, contentDescription = null, tint = Color.White)
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = layout.bottomPadding),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = layout.horizontalPadding),
                horizontalArrangement = Arrangement.spacedBy(if (layout.wide) 28.dp else 16.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                // LEFT AREA: logo OR channel name.
                HudBrandView(
                    brand = brand,
                    modifier = Modifier.width(if (layout.wide) 150.dp else 96.dp),
                    maxLogoWidth = if (layout.wide) 150.dp else 96.dp,
                    maxLogoHeight = if (layout.wide) 84.dp else 56.dp,
                    titleSize = if (layout.wide) 22.sp else 16.sp,
                    alignment = Alignment.BottomStart,
                )

                // MAIN INFORMATION AREA.
                LiveInfo(
                    content = content,
                    timing = timing,
                    showChannelName = liveShowsChannelNameInInfo(brand),
                    showDescription = showEpgDescription,
                    wide = layout.wide,
                    modifier = Modifier.weight(1f),
                )
            }

            // MAIN PROGRAMME PROGRESS: separate, wide bar below all information.
            if (timing != null) {
                LiveProgramBar(
                    timing = timing,
                    modifier = Modifier.padding(horizontal = layout.horizontalPadding),
                )
            }

            Column(
                modifier = Modifier.padding(horizontal = layout.horizontalPadding),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                LiveTransportControls(
                    hudState = hudState,
                    progress = progress,
                    actions = actions,
                    interaction = interaction,
                    wide = layout.wide,
                    primarySize = layout.primaryButtonSize,
                )
            }

            LiveTileRow(
                tiles = liveTiles(content, destinations),
                destinations = destinations,
                interaction = interaction,
                horizontalPadding = layout.horizontalPadding,
            )
        }
    }
}

@Composable
private fun rememberNowMs(): Long {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(5_000L)
            now = System.currentTimeMillis()
        }
    }

    return now
}

@Composable
private fun LiveInfo(
    content: PlayerHudContent.Live,
    timing: LiveProgramTiming?,
    showChannelName: Boolean,
    showDescription: Boolean,
    wide: Boolean,
    modifier: Modifier = Modifier,
) {
    val program = content.currentProgram
    val description = content.currentProgramDescription?.trim()?.takeIf { it.isNotEmpty() }
    val next = content.nextProgram

    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "LIVE",
                color = Color.Black,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier
                    .clip(RoundedCornerShape(5.dp))
                    .background(Color.White)
                    .padding(horizontal = 8.dp, vertical = 3.dp),
            )
            if (program != null) {
                Spacer(Modifier.width(10.dp))
                Text(
                    program.title,
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }

        if (timing != null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${formatClockTime(timing.startMs)} – ${formatClockTime(timing.endMs)}  ·  " +
                        formatRemaining(timing.remainingMs),
                    color = Color.White.copy(alpha = 0.78f),
                    style = MaterialTheme.typography.labelMedium,
                    maxLines = 1,
                )
                Spacer(Modifier.width(12.dp))
                // SMALL programme bar tied to the information block.
                LiveSmallProgressBar(
                    fraction = timing.fraction,
                    modifier = Modifier.width(if (wide) 120.dp else 72.dp),
                )
            }
        }

        if (showChannelName && content.channelName.isNotBlank()) {
            Text(
                content.channelName,
                color = Color.White.copy(alpha = 0.7f),
                style = MaterialTheme.typography.labelMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }

        if (showDescription && description != null) {
            Text(
                description,
                color = Color.White.copy(alpha = 0.82f),
                style = MaterialTheme.typography.bodySmall,
                maxLines = if (wide) 3 else 2,
                overflow = TextOverflow.Ellipsis,
            )
        }

        if (next != null && next.hasValidTimeRange) {
            Text(
                "Next  ${formatClockTime(next.startTimeMs)}  ${next.title}",
                color = Color.White.copy(alpha = 0.66f),
                style = MaterialTheme.typography.labelMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/** Small bar (information block). Display-only. */
@Composable
internal fun LiveSmallProgressBar(fraction: Float, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .height(3.dp)
            .clip(RoundedCornerShape(2.dp))
            .background(Color.White.copy(alpha = 0.24f)),
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(fraction.coerceIn(0f, 1f))
                .background(Color.White),
        )
    }
}

/** Wide main programme bar with start and end clock times. Display-only. */
@Composable
internal fun LiveProgramBar(timing: LiveProgramTiming, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            formatClockTime(timing.startMs),
            color = Color.White.copy(alpha = 0.8f),
            style = MaterialTheme.typography.labelMedium,
        )
        Box(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 12.dp)
                .height(5.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Color.White.copy(alpha = 0.22f)),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(timing.fraction.coerceIn(0f, 1f))
                    .background(Color.White),
            )
        }
        Text(
            formatClockTime(timing.endMs),
            color = Color.White.copy(alpha = 0.8f),
            style = MaterialTheme.typography.labelMedium,
        )
    }
}

/**
 * LIVE controls, separate from the Movie/Series row: play/pause always;
 * channel previous/next only when the queue has them; ±10 s only when the
 * engine reports the stream as seekable; preferences only with a destination.
 */
@Composable
private fun LiveTransportControls(
    hudState: PlayerHudState,
    progress: PlayerProgressState,
    actions: HudActions,
    interaction: HudInteraction,
    wide: Boolean,
    primarySize: Dp,
) {
    val caps = liveControlCapabilities(progress, hudState.hasPrevious, hudState.hasNext)

    Box(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.align(Alignment.Center),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (caps.showChannelPrevious) {
                HudButton(
                    onClick = { interaction.onInteract(); actions.onPrevious() },
                    description = "Previous channel",
                    onFocusChange = interaction.onFocusChange,
                ) { HudGlyph(HudGlyphKind.Previous, Color.White) }
            }
            if (caps.showSeek) {
                HudButton(
                    onClick = { interaction.onInteract(); actions.onSeekBackward() },
                    description = "Back 10 seconds",
                    onFocusChange = interaction.onFocusChange,
                ) { HudSeekLabel("−10") }
            }

            HudPlayPauseButton(
                isPlaying = hudState.isPlaying,
                onClick = { interaction.onInteract(); actions.onPlayPause() },
                size = primarySize,
                onFocusChange = interaction.onFocusChange,
                focusRequester = interaction.primaryFocus,
            )

            if (caps.showSeek) {
                HudButton(
                    onClick = { interaction.onInteract(); actions.onSeekForward() },
                    description = "Forward 10 seconds",
                    onFocusChange = interaction.onFocusChange,
                ) { HudSeekLabel("+10") }
            }
            if (caps.showChannelNext) {
                HudButton(
                    onClick = { interaction.onInteract(); actions.onNext() },
                    description = "Next channel",
                    onFocusChange = interaction.onFocusChange,
                ) { HudGlyph(HudGlyphKind.Next, Color.White) }
            }
        }

        actions.onOpenSettings?.let { openSettings ->
            HudButton(
                onClick = { interaction.onInteract(); openSettings() },
                description = "Player settings",
                modifier = Modifier.align(Alignment.CenterEnd),
                onFocusChange = interaction.onFocusChange,
                focusRequester = interaction.settingsFocus,
            ) {
                Icon(
                    Icons.Default.Settings,
                    contentDescription = null,
                    tint = Color.White,
                )
            }
        }
    }
}

@Composable
private fun LiveTileRow(
    tiles: List<LiveTile>,
    destinations: LiveHudDestinations,
    interaction: HudInteraction,
    horizontalPadding: Dp,
) {
    if (tiles.isEmpty()) return

    LazyRow(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = horizontalPadding),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        items(tiles) { tile ->
            when (tile) {
                LiveTile.TvGuide -> LiveTileCard(
                    onClick = destinations.onOpenTvGuide,
                    description = "TV Guide",
                    interaction = interaction,
                ) { TileLabel("TV Guide") }

                LiveTile.History -> LiveTileCard(
                    onClick = destinations.onOpenHistory,
                    description = "History",
                    interaction = interaction,
                ) { TileLabel("History") }

                is LiveTile.Recent -> {
                    val select = destinations.onSelectRecentChannel
                    val onSelect: (() -> Unit)? = select?.let { handler ->
                        { handler(tile.channel) }
                    }
                    LiveTileCard(
                        onClick = onSelect,
                        description = "Recently watched: ${tile.channel.channelName}",
                        interaction = interaction,
                    ) {
                        HudBrandView(
                            brand = resolveHudBrand(tile.channel.logoUrl, tile.channel.channelName),
                            maxLogoWidth = 84.dp,
                            maxLogoHeight = 28.dp,
                            titleSize = 13.sp,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TileLabel(text: String) {
    Text(
        text,
        color = Color.White,
        style = MaterialTheme.typography.labelLarge,
        maxLines = 1,
    )
}

/** Rounded tile. Without an [onClick] it is plain information: not clickable, not focusable. */
@Composable
private fun LiveTileCard(
    onClick: (() -> Unit)?,
    description: String,
    interaction: HudInteraction,
    content: @Composable () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val source = remember { MutableInteractionSource() }
    val shape = RoundedCornerShape(12.dp)

    Box(
        modifier = Modifier
            .height(48.dp)
            .clip(shape)
            .background(Color.White.copy(alpha = if (focused) 0.24f else 0.12f))
            .then(if (focused) Modifier.border(2.dp, Color.White, shape) else Modifier)
            .onFocusChanged {
                focused = it.isFocused
                interaction.onFocusChange(it.isFocused)
            }
            .semantics { contentDescription = description }
            .then(
                if (onClick != null) {
                    Modifier.clickable(
                        interactionSource = source,
                        indication = null,
                        role = Role.Button,
                        onClick = { interaction.onInteract(); onClick() },
                    )
                } else {
                    Modifier
                }
            )
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        content()
    }
}
