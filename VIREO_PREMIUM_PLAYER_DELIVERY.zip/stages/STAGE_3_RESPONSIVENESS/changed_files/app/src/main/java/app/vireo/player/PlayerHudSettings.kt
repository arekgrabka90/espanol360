package app.vireo.player

import app.vireo.data.local.ProfileSettingsEntity

/** Per-profile HUD preferences, independent of Compose. */
data class PlayerHudSettings(
    val autoHideSeconds: Int = HUD_AUTO_HIDE_DEFAULT_SECONDS,
    val keepVisibleWhenPaused: Boolean = true,
    val tapSeekEnabled: Boolean = true,
    val tapSeekSeconds: Int = 10,
    val isTv: Boolean = false,
)

val TAP_SEEK_OPTIONS_SECONDS: List<Int> = listOf(5, 10, 15, 30)

fun nextTapSeekSeconds(current: Int): Int {
    val i = TAP_SEEK_OPTIONS_SECONDS.indexOf(current)
    return TAP_SEEK_OPTIONS_SECONDS[(i + 1).mod(TAP_SEEK_OPTIONS_SECONDS.size)]
}

fun ProfileSettingsEntity.toHudSettings(isTv: Boolean) = PlayerHudSettings(
    autoHideSeconds = hudAutoHideSeconds,
    keepVisibleWhenPaused = hudKeepVisibleWhenPaused,
    tapSeekEnabled = tapSeekEnabled,
    tapSeekSeconds = tapSeekSeconds,
    isTv = isTv,
)

/** Writes only the HUD fields; every other profile setting is untouched. */
fun ProfileSettingsEntity.withHudSettings(value: PlayerHudSettings) = copy(
    hudAutoHideSeconds = value.autoHideSeconds,
    hudKeepVisibleWhenPaused = value.keepVisibleWhenPaused,
    tapSeekEnabled = value.tapSeekEnabled,
    tapSeekSeconds = value.tapSeekSeconds,
)

internal fun autoHideLabel(seconds: Int): String = if (seconds <= 0) "Off" else "$seconds s"
