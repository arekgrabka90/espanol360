package app.vireo.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HudStage3LogicTest {

    // ---- layout ----
    @Test
    fun `tv always gets the tv layout`() {
        assertEquals(HudFormFactor.Tv, hudLayoutSpec(1920, 1080, isTv = true).formFactor)
    }

    @Test
    fun `phone landscape portrait and tablet are told apart`() {
        assertEquals(HudFormFactor.PhoneLandscape, hudLayoutSpec(800, 360, false).formFactor)
        assertEquals(HudFormFactor.PhonePortrait, hudLayoutSpec(360, 780, false).formFactor)
        assertEquals(HudFormFactor.Tablet, hudLayoutSpec(1280, 800, false).formFactor)
    }

    @Test
    fun `short landscape phones use the compact height layout`() {
        assertTrue(hudLayoutSpec(800, 360, false).compactHeight)
        assertFalse(hudLayoutSpec(1280, 800, false).compactHeight)
    }

    @Test
    fun `layouts are not identical across form factors`() {
        val specs = listOf(
            hudLayoutSpec(360, 780, false),
            hudLayoutSpec(800, 360, false),
            hudLayoutSpec(1280, 800, false),
            hudLayoutSpec(1920, 1080, true),
        )

        assertEquals(4, specs.map { it.horizontalPaddingDp to it.episodeCardWidthDp }.toSet().size)
        assertTrue(specs.last().primaryButtonDp > specs.first().primaryButtonDp)
    }

    // ---- auto-hide ----
    @Test
    fun `auto hide options are the documented set with a conservative default`() {
        assertEquals(listOf(3, 5, 8, 10, 0), HUD_AUTO_HIDE_OPTIONS_SECONDS)
        assertEquals(8, HUD_AUTO_HIDE_DEFAULT_SECONDS)
    }

    @Test
    fun `cycling visits every option and wraps`() {
        var v = 3
        val seen = mutableListOf<Int>()
        repeat(5) { v = nextAutoHideSeconds(v); seen += v }

        assertEquals(listOf(5, 8, 10, 0, 3), seen)
        assertEquals(3, nextAutoHideSeconds(99)) // unknown values restart at the first option
    }

    @Test
    fun `hide delay follows the setting`() {
        assertEquals(5_000L, hudHideDelayMs(5, true, true, false, false))
        assertNull(hudHideDelayMs(0, true, true, false, false))
    }

    @Test
    fun `hud never hides while focused or while a panel is open`() {
        assertNull(hudHideDelayMs(5, true, true, hasFocusedControl = true, panelOpen = false))
        assertNull(hudHideDelayMs(5, true, true, hasFocusedControl = false, panelOpen = true))
    }

    @Test
    fun `paused hud stays only when the profile asks for it`() {
        assertNull(hudHideDelayMs(5, false, keepVisibleWhenPaused = true, false, false))
        assertEquals(5_000L, hudHideDelayMs(5, false, keepVisibleWhenPaused = false, false, false))
    }

    // ---- keys ----
    @Test
    fun `directional keys wake a hidden hud and are left alone when visible`() {
        listOf(HudKey.Up, HudKey.Down, HudKey.Left, HudKey.Right, HudKey.Center).forEach {
            assertEquals(HudKeyAction.WakeHud, hudKeyAction(it, hudVisible = false))
            assertEquals(HudKeyAction.None, hudKeyAction(it, hudVisible = true))
        }
    }

    @Test
    fun `media keys always act`() {
        assertEquals(HudKeyAction.TogglePlayback, hudKeyAction(HudKey.PlayPause, false))
        assertEquals(HudKeyAction.SeekForward, hudKeyAction(HudKey.FastForward, true))
        assertEquals(HudKeyAction.SeekBackward, hudKeyAction(HudKey.Rewind, false))
        assertEquals(HudKeyAction.Play, hudKeyAction(HudKey.Play, true))
        assertEquals(HudKeyAction.Pause, hudKeyAction(HudKey.Pause, true))
        assertEquals(HudKeyAction.None, hudKeyAction(HudKey.Other, false))
    }

    // ---- gestures ----
    @Test
    fun `tap zones split the screen in thirds`() {
        assertEquals(TapZone.Left, tapZone(100f, 1000f))
        assertEquals(TapZone.Middle, tapZone(500f, 1000f))
        assertEquals(TapZone.Right, tapZone(900f, 1000f))
        assertEquals(TapZone.Middle, tapZone(10f, 0f))
    }

    @Test
    fun `double tap seeks only when enabled and seekable`() {
        assertEquals(-10_000L, doubleTapSeekDeltaMs(TapZone.Left, true, 10, true))
        assertEquals(15_000L, doubleTapSeekDeltaMs(TapZone.Right, true, 15, true))
        assertNull(doubleTapSeekDeltaMs(TapZone.Middle, true, 10, true))
        assertNull(doubleTapSeekDeltaMs(TapZone.Left, false, 10, true))
        assertNull(doubleTapSeekDeltaMs(TapZone.Left, true, 10, false))
    }

    // ---- settings mapping ----
    @Test
    fun `seek step cycles through its options`() {
        assertEquals(10, nextTapSeekSeconds(5))
        assertEquals(5, nextTapSeekSeconds(30))
    }

    @Test
    fun `hud settings round trip through the profile entity without touching other fields`() {
        val base = app.vireo.data.local.ProfileSettingsEntity(profileId = 3L, accentColor = "teal")
        val updated = base.withHudSettings(
            PlayerHudSettings(autoHideSeconds = 3, keepVisibleWhenPaused = false, tapSeekEnabled = false, tapSeekSeconds = 30)
        )

        assertEquals("teal", updated.accentColor)
        assertEquals(3L, updated.profileId)
        assertEquals(
            PlayerHudSettings(3, false, false, 30, isTv = true),
            updated.toHudSettings(isTv = true),
        )
    }

    @Test
    fun `auto hide label`() {
        assertEquals("Off", autoHideLabel(0))
        assertEquals("8 s", autoHideLabel(8))
    }
}
