# 2B.3A_LIVE_LOGO_PERSISTENCE

Room column logoUrl, Xtream channel mapping, migration helper. Needs Title.kt / TitleListViewModel / @Database edits (files not supplied).

**Depends on:** 2B.3A_PLAYER_FOUNDATION + docs/MANUAL_CHANGES_REQUIRED.md

**Apply:** from the VIREO repo root `patch -p1 < patch.diff` (patches are sequential, in the order listed in IMPLEMENTATION_REPORT.md), or copy `changed_files/` over the repo (complete files; each stage's files are the state AFTER that stage).

**Files:** see FILES.txt. **Not executed:** build and tests (see TEST_REPORT.md).
