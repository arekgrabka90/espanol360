package app.vireo.data.local

import org.junit.Assert.assertTrue
import org.junit.Test

class PlayerHudMigrationsTest {

    @Test
    fun `logo column is added to the xtream catalog items table`() {
        assertTrue(
            PlayerHudMigrations.STATEMENTS.any {
                it.startsWith("ALTER TABLE xtream_catalog_items ADD COLUMN logoUrl")
            }
        )
    }

    @Test
    fun `backfill only touches LIVE rows that actually have an icon`() {
        val backfill = PlayerHudMigrations.STATEMENTS.single { it.startsWith("UPDATE") }

        assertTrue(backfill.contains("contentType = 'LIVE'"))
        assertTrue(backfill.contains("posterUrl IS NOT NULL"))
        assertTrue(backfill.contains("SET logoUrl = posterUrl"))
    }

    @Test
    fun `column is added before the backfill uses it`() {
        val alter = PlayerHudMigrations.STATEMENTS.indexOfFirst { it.startsWith("ALTER") }
        val update = PlayerHudMigrations.STATEMENTS.indexOfFirst { it.startsWith("UPDATE") }

        assertTrue(alter in 0 until update)
    }
}
