package app.vireo.player

import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

/**
 * Renders the HUD brand slot: the logo OR the title, never both.
 *
 * The logo keeps its natural aspect ratio (ContentScale.Fit) on a transparent
 * background. If it fails to load, the text title replaces it.
 */
@Composable
fun HudBrandView(
    brand: HudBrand,
    modifier: Modifier = Modifier,
    maxLogoWidth: Dp = 260.dp,
    maxLogoHeight: Dp = 72.dp,
    titleSize: TextUnit = 24.sp,
    alignment: Alignment = Alignment.CenterStart,
) {
    when (brand) {
        HudBrand.None -> Unit

        is HudBrand.Title -> HudTitleText(brand.text, modifier, titleSize)

        is HudBrand.Logo -> {
            var failed by remember(brand.url) { mutableStateOf(false) }

            if (failed) {
                if (brand.fallbackTitle.isNotEmpty()) {
                    HudTitleText(brand.fallbackTitle, modifier, titleSize)
                }
            } else {
                AsyncImage(
                    model = brand.url,
                    contentDescription = brand.fallbackTitle.ifEmpty { null },
                    contentScale = ContentScale.Fit,
                    alignment = alignment,
                    onError = { failed = true },
                    modifier = modifier
                        .widthIn(max = maxLogoWidth)
                        .heightIn(max = maxLogoHeight),
                )
            }
        }
    }
}

@Composable
private fun HudTitleText(text: String, modifier: Modifier, size: TextUnit) {
    Text(
        text = text,
        modifier = modifier,
        color = Color.White,
        fontSize = size,
        fontWeight = FontWeight.SemiBold,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
    )
}
