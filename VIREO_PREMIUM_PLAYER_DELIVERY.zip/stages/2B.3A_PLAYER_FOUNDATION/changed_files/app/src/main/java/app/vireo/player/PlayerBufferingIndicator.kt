package app.vireo.player

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

/**
 * Buffering indication drawn over the live video surface.
 *
 * It never draws a scrim, poster or backdrop: only a small transparent logo
 * (movies/series) or a restrained spinner. The technique (infinite transition,
 * reversing tween, subtle scale + alpha) was independently written following
 * the same idea as ARVIO's loading animation; no ARVIO code is copied.
 */
@Composable
fun PlayerBufferingIndicator(
    content: PlayerHudContent,
    modifier: Modifier = Modifier,
) {
    val logoUrl = content.bufferingLogoUrl()
    var logoFailed by remember(logoUrl) { mutableStateOf(false) }

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        if (content.usesLogoBuffering() && logoUrl != null && !logoFailed) {
            PulsingLogo(logoUrl = logoUrl, onError = { logoFailed = true })
        } else {
            // LIVE, or movie/series without a (working) logo: discreet spinner.
            CircularProgressIndicator(
                modifier = Modifier.size(if (content is PlayerHudContent.Live) 24.dp else 32.dp),
                color = Color.White.copy(alpha = 0.78f),
                strokeWidth = 2.dp,
            )
        }
    }
}

@Composable
private fun PulsingLogo(logoUrl: String, onError: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "bufferingLogo")
    val scale by transition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1_100),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "bufferingLogoScale",
    )
    val alpha by transition.animateFloat(
        initialValue = 0.62f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1_100),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "bufferingLogoAlpha",
    )

    AsyncImage(
        model = logoUrl,
        contentDescription = null,
        // Natural aspect ratio, never stretched; bounded so it stays subtle.
        contentScale = ContentScale.Fit,
        onError = { onError() },
        modifier = Modifier
            .widthIn(max = 220.dp)
            .heightIn(max = 96.dp)
            .scale(scale)
            .alpha(alpha),
    )
}
