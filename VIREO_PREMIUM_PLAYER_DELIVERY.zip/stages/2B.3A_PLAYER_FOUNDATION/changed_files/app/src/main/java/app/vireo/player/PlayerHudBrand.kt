package app.vireo.player

/**
 * What the HUD shows in the "left / title" slot.
 *
 * Logo and title are mutually exclusive: [Logo] carries the text only as the
 * fallback that the UI uses if the image fails to load, never to render both.
 * A poster or backdrop is never a candidate. Pure Kotlin, no Compose/Media3.
 */
sealed interface HudBrand {
    data class Logo(val url: String, val fallbackTitle: String) : HudBrand
    data class Title(val text: String) : HudBrand
    data object None : HudBrand
}

internal fun resolveHudBrand(logoUrl: String?, title: String?): HudBrand {
    val logo = logoUrl?.trim()?.takeIf { it.isNotEmpty() }
    val text = title?.trim().orEmpty()

    return when {
        logo != null -> HudBrand.Logo(logo, text)
        text.isNotEmpty() -> HudBrand.Title(text)
        else -> HudBrand.None
    }
}

/** Brand for the content currently shown by the HUD. */
internal fun PlayerHudContent.brand(): HudBrand = when (this) {
    is PlayerHudContent.Movie -> resolveHudBrand(logoUrl, title)
    is PlayerHudContent.Series -> resolveHudBrand(logoUrl, title)
    is PlayerHudContent.Live -> resolveHudBrand(logoUrl, channelName)
    is PlayerHudContent.Other -> resolveHudBrand(null, title)
}

/** Logo used by the buffering animation; only movies and series have one. */
internal fun PlayerHudContent.bufferingLogoUrl(): String? = when (this) {
    is PlayerHudContent.Movie -> logoUrl
    is PlayerHudContent.Series -> logoUrl
    else -> null
}?.trim()?.takeIf { it.isNotEmpty() }

/** True for content that uses the animated-logo buffering indicator. */
internal fun PlayerHudContent.usesLogoBuffering(): Boolean =
    this is PlayerHudContent.Movie || this is PlayerHudContent.Series
