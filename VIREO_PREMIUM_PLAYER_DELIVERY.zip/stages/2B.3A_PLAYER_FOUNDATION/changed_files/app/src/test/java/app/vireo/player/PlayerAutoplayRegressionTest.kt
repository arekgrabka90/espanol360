package app.vireo.player

import app.vireo.data.ContentRepository
import app.vireo.data.EpgRepository
import app.vireo.data.LibraryRepository
import app.vireo.data.ProfileRepository
import app.vireo.data.ProfileSettingsRepository
import app.vireo.data.local.LiveChannelHistoryDao
import app.vireo.data.local.ProfileEntity
import app.vireo.data.local.ProfileSettingsEntity
import app.vireo.player.engine.Media3PlayerEngine
import app.vireo.player.source.PlaybackSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.mockito.Mockito

/**
 * Guards the existing autoplay lifecycle (desiredPlayWhenReady = true,
 * startPlayback -> play after prepare) for movies, series and LIVE, including
 * items that now carry logo metadata. Same harness as
 * PlayerViewModelIntegrationTest; no second autoplay mechanism is introduced.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class PlayerAutoplayRegressionTest {

    private lateinit var session: PlaybackSession
    private lateinit var engine: Media3PlayerEngine
    private lateinit var content: ContentRepository
    private lateinit var library: LibraryRepository
    private lateinit var profiles: ProfileRepository
    private lateinit var epg: EpgRepository
    private lateinit var settings: ProfileSettingsRepository
    private lateinit var liveHistory: LiveChannelHistoryDao

    private val profile = ProfileEntity(id = 1L, name = "Test", kids = false)
    private val profileSettings = ProfileSettingsEntity(profileId = 1L)

    @Before
    fun setUp() {
        Dispatchers.setMain(StandardTestDispatcher())
        session = PlaybackSession()
        engine = Mockito.mock(Media3PlayerEngine::class.java)
        content = Mockito.mock(ContentRepository::class.java)
        library = Mockito.mock(LibraryRepository::class.java)
        profiles = Mockito.mock(ProfileRepository::class.java)
        epg = Mockito.mock(EpgRepository::class.java)
        settings = Mockito.mock(ProfileSettingsRepository::class.java)
        liveHistory = Mockito.mock(LiveChannelHistoryDao::class.java)

        Mockito.`when`(profiles.activeId).thenReturn(1L)
        Mockito.`when`(settings.observe(1L))
            .thenReturn(MutableStateFlow(profileSettings))
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    private suspend fun createViewModel(scope: TestScope): PlayerViewModel {
        Mockito.`when`(profiles.get(1L)).thenReturn(profile)
        Mockito.`when`(settings.ensure(profileId = 1L, kidsMode = false))
            .thenReturn(profileSettings)

        return PlayerViewModel(
            session = session,
            media3PlayerEngine = engine,
            contentRepository = content,
            library = library,
            profiles = profiles,
            epgRepository = epg,
            profileSettingsRepository = settings,
            liveChannelHistoryDao = liveHistory,
            applicationScope = scope.backgroundScope,
        ).also { scope.advanceUntilIdle() }
    }

    @Test
    fun `autoplay intent defaults to true`() = runTest {
        val item = PlayItem(title = "M", url = "u", contentType = "MOVIE")
        session.start(listOf(item), 0)

        val viewModel = createViewModel(this)

        assertTrue(viewModel.state.value.desiredPlayWhenReady)
    }

    @Test
    fun `movie with logo metadata still starts playing after prepare`() = runTest {
        val item = PlayItem(
            title = "M", url = "u", contentType = "MOVIE", logoUrl = "https://img/l.png",
        )
        val source = PlaybackSource(url = "https://example.invalid/resolved")
        session.start(listOf(item), 0)
        Mockito.`when`(content.resolvePlaybackSource(item)).thenReturn(source)

        val viewModel = createViewModel(this)
        viewModel.startPlayback(item, 5_000L)
        advanceUntilIdle()

        Mockito.verify(engine).setSource(source, 5_000L)
        Mockito.verify(engine).prepare()
        Mockito.verify(engine).play()
    }

    @Test
    fun `series episode with logo metadata still starts playing`() = runTest {
        val item = PlayItem(
            title = "Show · S1 E1 · Pilot",
            url = "u",
            contentType = "SERIES",
            seriesTitle = "Show",
            episodeTitle = "Pilot",
            logoUrl = "https://img/l.png",
        )
        val source = PlaybackSource(url = "https://example.invalid/resolved")
        session.start(listOf(item), 0)
        Mockito.`when`(content.resolvePlaybackSource(item)).thenReturn(source)

        val viewModel = createViewModel(this)
        viewModel.startPlayback(item, 0L)
        advanceUntilIdle()

        Mockito.verify(engine).play()
    }

    @Test
    fun `live channel starts from zero and plays`() = runTest {
        val item = PlayItem(
            title = "Channel",
            url = "u",
            contentType = "LIVE",
            logoUrl = "https://img/channel.png",
        )
        val source = PlaybackSource(url = "https://example.invalid/live")
        session.start(listOf(item), 0)
        Mockito.`when`(content.resolvePlaybackSource(item)).thenReturn(source)

        val viewModel = createViewModel(this)
        viewModel.startPlayback(item, 99_000L)
        advanceUntilIdle()

        Mockito.verify(engine).setSource(source, 0L)
        Mockito.verify(engine).play()
    }

    @Test
    fun `pause then resume restores the play intent`() = runTest {
        val item = PlayItem(title = "M", url = "u", contentType = "MOVIE")
        session.start(listOf(item), 0)

        val viewModel = createViewModel(this)

        viewModel.pausePlayback()
        assertFalse(viewModel.state.value.desiredPlayWhenReady)

        viewModel.resumePlayback()
        assertTrue(viewModel.state.value.desiredPlayWhenReady)
    }
}
