package app.vireo.player

import app.vireo.domain.model.EpgNowNext
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PlayerHudLogoPropagationTest {

    private fun hud(item: PlayItem) = buildPlayerHudState(
        PlayerUiState(item = item),
        EpgNowNext(null, null),
        emptyList(),
    ).content

    @Test
    fun `movie logo reaches the movie HUD and is not the poster`() {
        val movie = hud(
            PlayItem(
                title = "Movie",
                url = "u",
                contentType = "MOVIE",
                posterUrl = "https://img/poster.jpg",
                backdropUrl = "https://img/backdrop.jpg",
                logoUrl = "https://img/logo.png",
            )
        ) as PlayerHudContent.Movie

        assertEquals("https://img/logo.png", movie.logoUrl)
        assertEquals("https://img/poster.jpg", movie.posterUrl)
    }

    @Test
    fun `movie without logo never borrows poster or backdrop`() {
        val movie = hud(
            PlayItem(
                title = "Movie",
                url = "u",
                contentType = "MOVIE",
                posterUrl = "https://img/poster.jpg",
                backdropUrl = "https://img/backdrop.jpg",
            )
        ) as PlayerHudContent.Movie

        assertNull(movie.logoUrl)
        assertEquals(HudBrand.Title("Movie"), movie.brand())
    }

    @Test
    fun `series logo reaches the series HUD`() {
        val series = hud(
            PlayItem(
                title = "Show · S1 E2 · Pilot",
                url = "u",
                contentType = "SERIES",
                seriesId = "s",
                seasonNumber = 1,
                episodeNumber = 2,
                logoUrl = "https://img/show-logo.png",
                posterUrl = "https://img/poster.jpg",
            )
        ) as PlayerHudContent.Series

        assertEquals("https://img/show-logo.png", series.logoUrl)
    }

    @Test
    fun `series HUD title is the bare series name when provided`() {
        val series = hud(
            PlayItem(
                title = "Show · S1 E2 · Pilot",
                url = "u",
                contentType = "SERIES",
                seriesTitle = "Show",
                episodeTitle = "Pilot",
                seasonNumber = 1,
                episodeNumber = 2,
            )
        ) as PlayerHudContent.Series

        assertEquals("Show", series.title)
        assertEquals("Pilot", series.currentEpisodeTitle)
        assertEquals(1, series.seasonNumber)
        assertEquals(2, series.episodeNumber)
    }

    @Test
    fun `series HUD falls back to composed title for legacy items`() {
        val series = hud(
            PlayItem(
                title = "Legacy series",
                url = "u",
                contentType = "SERIES",
                seriesId = "s",
            )
        ) as PlayerHudContent.Series

        assertEquals("Legacy series", series.title)
        assertNull(series.currentEpisodeTitle)
    }

    @Test
    fun `current episode metadata comes from the episode list when present`() {
        val episode = PlaybackEpisode(
            title = "From list",
            seasonNumber = 2,
            episodeNumber = 3,
            description = "Episode text",
            thumbnailUrl = "thumb",
        )
        val series = hud(
            PlayItem(
                title = "Show",
                url = "u",
                contentType = "SERIES",
                seasonNumber = 2,
                episodeNumber = 3,
                episodeTitle = "Fallback title",
                episodes = listOf(episode),
            )
        ) as PlayerHudContent.Series

        assertEquals("From list", series.currentEpisodeTitle)
        assertEquals("Episode text", series.currentEpisodeDescription)
        assertEquals("thumb", series.currentEpisodeThumbnailUrl)
    }

    @Test
    fun `episode description has priority over series description`() {
        val series = hud(
            PlayItem(
                title = "Show",
                url = "u",
                contentType = "SERIES",
                seriesId = "s",
                description = "Series text",
                episodeDescription = "Episode text",
            )
        ) as PlayerHudContent.Series

        assertEquals("Episode text", series.displayDescription())
    }

    @Test
    fun `series description is used only when episode description is missing or blank`() {
        val missing = hud(
            PlayItem(
                title = "Show",
                url = "u",
                contentType = "SERIES",
                seriesId = "s",
                description = "Series text",
            )
        ) as PlayerHudContent.Series
        val blank = hud(
            PlayItem(
                title = "Show",
                url = "u",
                contentType = "SERIES",
                seriesId = "s",
                description = "Series text",
                episodeDescription = "   ",
            )
        ) as PlayerHudContent.Series
        val none = hud(
            PlayItem(title = "Show", url = "u", contentType = "SERIES", seriesId = "s")
        ) as PlayerHudContent.Series

        assertEquals("Series text", missing.displayDescription())
        assertEquals("Series text", blank.displayDescription())
        assertNull(none.displayDescription())
    }

    @Test
    fun `live HUD uses the channel logo and never the poster`() {
        val live = hud(
            PlayItem(
                title = "Channel",
                url = "u",
                contentType = "LIVE",
                posterUrl = "https://img/poster-like.jpg",
                logoUrl = "https://img/channel-logo.png",
            )
        ) as PlayerHudContent.Live

        assertEquals("https://img/channel-logo.png", live.logoUrl)
    }

    @Test
    fun `live channel without a logo does not fall back to the poster`() {
        val live = hud(
            PlayItem(
                title = "Channel",
                url = "u",
                contentType = "LIVE",
                posterUrl = "https://img/poster-like.jpg",
            )
        ) as PlayerHudContent.Live

        assertNull(live.logoUrl)
        assertEquals(HudBrand.Title("Channel"), live.brand())
    }

    @Test
    fun `alternative source keeps logo and series naming`() {
        val session = PlaybackSession()
        session.start(
            listOf(
                PlayItem(
                    title = "Show · S1 E1 · Pilot",
                    url = "primary",
                    contentType = "SERIES",
                    logoUrl = "logo",
                    seriesTitle = "Show",
                    episodeTitle = "Pilot",
                    alternatives = listOf(
                        PlaybackAlternative(sourceId = 2L, streamId = "x", url = "alt"),
                    ),
                )
            ),
            0,
        )

        val alternative = session.nextAlternative()!!

        assertEquals("alt", alternative.url)
        assertEquals("logo", alternative.logoUrl)
        assertEquals("Show", alternative.seriesTitle)
        assertEquals("Pilot", alternative.episodeTitle)
    }

    @Test
    fun `empty metadata stays null and is not replaced by placeholders`() {
        val movie = hud(
            PlayItem(title = "Bare", url = "u", contentType = "MOVIE")
        ) as PlayerHudContent.Movie

        assertNull(movie.description)
        assertNull(movie.year)
        assertNull(movie.genre)
        assertNull(movie.duration)
        assertNull(movie.rating)
        assertNull(movie.logoUrl)
    }

    @Test
    fun `buffering logo exists only for movies and series`() {
        val movie = hud(
            PlayItem(title = "M", url = "u", contentType = "MOVIE", logoUrl = "l")
        )
        val live = hud(
            PlayItem(title = "C", url = "u", contentType = "LIVE", logoUrl = "l")
        )

        assertTrue(movie.usesLogoBuffering())
        assertEquals("l", movie.bufferingLogoUrl())
        assertFalse(live.usesLogoBuffering())
        assertNull(live.bufferingLogoUrl())
    }
}
