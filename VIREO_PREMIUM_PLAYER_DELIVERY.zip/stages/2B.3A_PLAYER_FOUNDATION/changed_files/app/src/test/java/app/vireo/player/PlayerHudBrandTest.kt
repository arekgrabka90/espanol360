package app.vireo.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PlayerHudBrandTest {

    @Test
    fun `valid logo wins and title is only a load-failure fallback`() {
        val brand = resolveHudBrand("https://img/l.png", "Title")

        assertTrue(brand is HudBrand.Logo)
        assertEquals("Title", (brand as HudBrand.Logo).fallbackTitle)
    }

    @Test
    fun `blank logo falls back to the title`() {
        assertEquals(HudBrand.Title("Title"), resolveHudBrand("   ", "Title"))
        assertEquals(HudBrand.Title("Title"), resolveHudBrand(null, " Title "))
    }

    @Test
    fun `nothing available resolves to None without placeholders`() {
        assertEquals(HudBrand.None, resolveHudBrand(null, null))
        assertEquals(HudBrand.None, resolveHudBrand("", "  "))
    }

    @Test
    fun `logo and title are mutually exclusive types`() {
        val results = listOf(
            resolveHudBrand("l", "t"),
            resolveHudBrand(null, "t"),
            resolveHudBrand(null, null),
        )

        results.forEach {
            val representations = listOf(
                it is HudBrand.Logo,
                it is HudBrand.Title,
            ).count { present -> present }
            assertTrue(representations <= 1)
        }
    }

    @Test
    fun `other content never shows a logo`() {
        val other = PlayerHudContent.Other(title = "Now", posterUrl = "poster")

        assertEquals(HudBrand.Title("Now"), other.brand())
    }
}
