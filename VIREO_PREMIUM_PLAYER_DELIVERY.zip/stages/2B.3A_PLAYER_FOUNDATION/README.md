# 2B.3A_PLAYER_FOUNDATION

Logo propagation, logo XOR title, removal of artwork over the video, logo buffering animation, LIVE HUD mapping (no poster as logo).

**Depends on:** none (baseline)

**Apply:** from the VIREO repo root `patch -p1 < patch.diff` (patches are sequential, in the order listed in IMPLEMENTATION_REPORT.md), or copy `changed_files/` over the repo (complete files; each stage's files are the state AFTER that stage).

**Files:** see FILES.txt. **Not executed:** build and tests (see TEST_REPORT.md).
