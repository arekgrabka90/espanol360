package app.vireo.player

import app.vireo.domain.model.EpgNowNext

/**
 * UI-ready data for the future shared Compose HUD.
 * This model has no Compose or Media3 dependencies.
 */
data class PlayerHudState(
    val content: PlayerHudContent,
    val transportState: PlayerTransportState,
    val isPlaying: Boolean,
    val hasPrevious: Boolean,
    val hasNext: Boolean,
    val controlsVisible: Boolean,
    val errorMessage: String?,
)

sealed interface PlayerHudContent {
    data class Movie(
        val title: String,
        val description: String?,
        val year: String?,
        val genre: String?,
        val duration: String?,
        val rating: String?,
        val posterUrl: String?,
        val backdropUrl: String?,
        val logoUrl: String? = null,
    ) : PlayerHudContent

    data class Series(
        val title: String,
        val description: String?,
        val year: String?,
        val genre: String?,
        val rating: String?,
        val posterUrl: String?,
        val backdropUrl: String?,
        val currentEpisode: PlaybackEpisode?,
        val currentEpisodeDescription: String?,
        val currentEpisodeThumbnailUrl: String?,
        val episodes: List<PlaybackEpisode>,
        val logoUrl: String? = null,
        val seasonNumber: Int? = null,
        val episodeNumber: Int? = null,
        val currentEpisodeTitle: String? = null,
        /** Episodes that can be started from the current queue. */
        val queuedEpisodes: Set<EpisodeKey> = emptySet(),
    ) : PlayerHudContent

    data class Live(
        val channelName: String,
        val epgChannelId: String?,
        val streamId: String?,
        val logoUrl: String?,
        val currentProgram: app.vireo.domain.model.EpgProgram?,
        val currentProgramDescription: String?,
        val nextProgram: app.vireo.domain.model.EpgProgram?,
        val recentChannels: List<RecentLiveChannel>,
    ) : PlayerHudContent

    data class Other(
        val title: String,
        val posterUrl: String?,
    ) : PlayerHudContent
}

data class RecentLiveChannel(
    val sourceId: Long,
    val streamId: String,
    val channelName: String,
    val epgChannelId: String?,
    val logoUrl: String?,
    val lastPlayedAt: Long,
)

internal fun buildPlayerHudState(
    state: PlayerUiState,
    epg: EpgNowNext,
    recentChannels: List<RecentLiveChannel>,
): PlayerHudState {
    val item = state.item

    val contentType = item?.contentType ?: state.runtime.contentType

    val content = when {
        item == null -> PlayerHudContent.Other("", null)

        contentType == "LIVE" -> PlayerHudContent.Live(
            channelName = item.title,
            epgChannelId = item.epgChannelId,
            streamId = item.streamId,
            // Channel logo only. A poster is never used as a logo.
            logoUrl = item.logoUrl,
            currentProgram = epg.current,
            currentProgramDescription = epg.current?.description,
            nextProgram = epg.next,
            recentChannels = recentChannels,
        )

        contentType == "SERIES" ||
            item.seriesId != null ||
            item.episodes.isNotEmpty() -> {
            val currentEpisode = item.episodes.firstOrNull {
                it.seasonNumber == item.seasonNumber &&
                    it.episodeNumber == item.episodeNumber
            }

            PlayerHudContent.Series(
                // seriesTitle is the bare series name; title carries the
                // "S1 E2 · episode" suffix for episode PlayItems.
                title = item.seriesTitle?.takeIf { it.isNotBlank() }
                    ?: item.title,
                description = item.description,
                year = item.year,
                genre = item.genre,
                rating = item.rating,
                posterUrl = item.posterUrl,
                backdropUrl = item.backdropUrl,
                currentEpisode = currentEpisode,
                currentEpisodeDescription =
                    currentEpisode?.description ?: item.episodeDescription,
                currentEpisodeThumbnailUrl =
                    currentEpisode?.thumbnailUrl ?: item.episodeThumbnailUrl,
                episodes = item.episodes,
                logoUrl = item.logoUrl,
                seasonNumber = item.seasonNumber,
                episodeNumber = item.episodeNumber,
                currentEpisodeTitle = currentEpisode?.title
                    ?.takeIf { it.isNotBlank() }
                    ?: item.episodeTitle?.takeIf { it.isNotBlank() },
                queuedEpisodes = state.queuedEpisodes,
            )
        }

        contentType == "MOVIE" -> PlayerHudContent.Movie(
            title = item.title,
            description = item.description,
            year = item.year,
            genre = item.genre,
            duration = item.duration,
            rating = item.rating,
            posterUrl = item.posterUrl,
            backdropUrl = item.backdropUrl,
            logoUrl = item.logoUrl,
        )

        else -> PlayerHudContent.Other(
            title = item.title,
            posterUrl = item.posterUrl,
        )
    }

    return PlayerHudState(
        content = content,
        transportState = state.runtime.transportState,
        isPlaying = state.runtime.isPlaying,
        hasPrevious = state.hasPrevious,
        hasNext = state.hasNext,
        controlsVisible = state.runtime.controlsVisible,
        errorMessage = state.error,
    )
}

/**
 * Series description shown by the HUD. The current episode's description has
 * priority; the series description is an intentional fallback only when the
 * episode has none. Blank strings count as missing.
 */
internal fun PlayerHudContent.Series.displayDescription(): String? =
    currentEpisodeDescription?.trim()?.takeIf { it.isNotEmpty() }
        ?: description?.trim()?.takeIf { it.isNotEmpty() }

/** "S02 · E03", or null when numbering is unknown. */
internal fun seriesEpisodeLabel(season: Int?, episode: Int?): String? {
    if (season == null || episode == null) return null
    return "S${season.toString().padStart(2, '0')} · E${episode.toString().padStart(2, '0')}"
}

/** Index of the playing episode in [PlayerHudContent.Series.episodes], or -1. */
internal fun PlayerHudContent.Series.currentEpisodeIndex(): Int {
    val season = seasonNumber ?: return -1
    val number = episodeNumber ?: return -1
    return episodes.indexOfFirst {
        it.seasonNumber == season && it.episodeNumber == number
    }
}

/** An episode card is selectable if it is playing now or present in the queue. */
internal fun PlayerHudContent.Series.canPlay(episode: PlaybackEpisode): Boolean =
    EpisodeKey(episode.seasonNumber, episode.episodeNumber) in queuedEpisodes
