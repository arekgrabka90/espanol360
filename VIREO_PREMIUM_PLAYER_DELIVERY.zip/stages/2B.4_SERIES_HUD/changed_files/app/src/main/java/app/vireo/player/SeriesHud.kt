package app.vireo.player

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

/** Metadata line for a series (year, genre, rating); only values that exist. */
internal fun seriesMetadataParts(content: PlayerHudContent.Series): List<String> =
    listOfNotNull(
        content.year?.trim()?.takeIf { it.isNotEmpty() },
        content.genre?.trim()?.takeIf { it.isNotEmpty() },
        content.rating?.trim()?.takeIf { it.isNotEmpty() }?.let { "★ $it" },
    )

/**
 * Series HUD: transparent layer over the real video.
 * Logo or title, current episode (number + title), the episode's own
 * description (series description only as fallback), a horizontally scrollable
 * episode row, then the same progress and transport controls as the Movie HUD.
 */
@Composable
internal fun SeriesHud(
    content: PlayerHudContent.Series,
    hudState: PlayerHudState,
    progress: PlayerProgressState,
    actions: HudActions,
    interaction: HudInteraction,
    layout: HudLayoutMetrics,
) {
    Box(modifier = Modifier.fillMaxSize()) {
        HudEdgeScrim(top = true, height = if (layout.wide) 170.dp else 120.dp)
        HudEdgeScrim(top = false, height = if (layout.wide) 440.dp else 330.dp)

        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .fillMaxWidth()
                .padding(horizontal = layout.horizontalPadding, vertical = layout.topPadding),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            HudButton(
                onClick = { interaction.onInteract(); actions.onBack() },
                description = "Back",
                onFocusChange = interaction.onFocusChange,
            ) {
                Icon(Icons.Default.Close, contentDescription = null, tint = Color.White)
            }
            Spacer(Modifier.width(18.dp))
            HudBrandView(
                brand = content.brand(),
                titleSize = if (layout.wide) 26.sp else 20.sp,
            )
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = layout.bottomPadding),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            SeriesInfo(
                content = content,
                expanded = !hudState.isPlaying,
                wide = layout.wide,
                modifier = Modifier.padding(horizontal = layout.horizontalPadding),
            )

            if (content.episodes.isNotEmpty()) {
                EpisodeThumbnailRow(
                    content = content,
                    onSelect = actions.onSelectEpisode,
                    interaction = interaction,
                    cardWidth = if (layout.wide) 176.dp else 116.dp,
                    horizontalPadding = layout.horizontalPadding,
                )
            }

            Column(
                modifier = Modifier.padding(horizontal = layout.horizontalPadding),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                HudProgressRow(
                    progress = progress,
                    interaction = interaction,
                    onSeekTo = actions.onSeekTo,
                )
                HudTransportControls(
                    hudState = hudState,
                    progress = progress,
                    actions = actions,
                    interaction = interaction,
                    wide = layout.wide,
                )
            }
        }
    }
}

@Composable
private fun SeriesInfo(
    content: PlayerHudContent.Series,
    expanded: Boolean,
    wide: Boolean,
    modifier: Modifier = Modifier,
) {
    val label = seriesEpisodeLabel(content.seasonNumber, content.episodeNumber)
    val episodeTitle = content.currentEpisodeTitle
    val description = content.displayDescription()
    val parts = seriesMetadataParts(content)

    if (label == null && episodeTitle == null && description == null && parts.isEmpty()) return

    Column(
        modifier = modifier
            .fillMaxWidth(if (wide) 0.66f else 0.94f)
            .animateContentSize(),
        verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        val heading = listOfNotNull(label, episodeTitle).joinToString("  ·  ")
        if (heading.isNotEmpty()) {
            Text(
                heading,
                color = Color.White,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (parts.isNotEmpty()) {
            Text(
                parts.joinToString("   ·   "),
                color = Color.White.copy(alpha = 0.7f),
                style = MaterialTheme.typography.labelMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (description != null) {
            Text(
                description,
                color = Color.White.copy(alpha = 0.84f),
                style = MaterialTheme.typography.bodySmall,
                maxLines = if (expanded && wide) 4 else 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/**
 * Horizontally scrollable row of the series' real episodes.
 * The playing episode has a white outline and a "NOW PLAYING" tag. Cards keep a
 * 16:9 frame; images are cropped to it, never stretched. D-pad: left/right moves
 * focus between cards (each card shows a focus ring); touch: drag to scroll.
 */
@Composable
internal fun EpisodeThumbnailRow(
    content: PlayerHudContent.Series,
    onSelect: ((season: Int, episode: Int) -> Unit)?,
    interaction: HudInteraction,
    cardWidth: Dp,
    horizontalPadding: Dp,
) {
    val currentIndex = content.currentEpisodeIndex()
    val listState = rememberLazyListState(
        initialFirstVisibleItemIndex = currentIndex.coerceAtLeast(0),
    )

    LaunchedEffect(currentIndex) {
        if (currentIndex >= 0) listState.animateScrollToItem(currentIndex)
    }

    LazyRow(
        state = listState,
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = horizontalPadding),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        itemsIndexed(
            items = content.episodes,
            key = { _, episode -> "${episode.seasonNumber}x${episode.episodeNumber}" },
        ) { index, episode ->
            EpisodeCard(
                episode = episode,
                isCurrent = index == currentIndex,
                enabled = onSelect != null && content.canPlay(episode),
                width = cardWidth,
                interaction = interaction,
                onClick = { onSelect?.invoke(episode.seasonNumber, episode.episodeNumber) },
            )
        }
    }
}

@Composable
private fun EpisodeCard(
    episode: PlaybackEpisode,
    isCurrent: Boolean,
    enabled: Boolean,
    width: Dp,
    interaction: HudInteraction,
    onClick: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val source = remember { MutableInteractionSource() }
    val shape = RoundedCornerShape(8.dp)
    val number = "E${episode.episodeNumber}"
    var imageFailed by remember(episode.thumbnailUrl) { mutableStateOf(false) }
    val thumbnail = episode.thumbnailUrl?.trim()?.takeIf { it.isNotEmpty() && !imageFailed }

    Column(
        modifier = Modifier
            .width(width)
            .alpha(if (enabled || isCurrent) 1f else 0.5f)
            .onFocusChanged {
                focused = it.isFocused
                interaction.onFocusChange(it.isFocused)
            }
            .semantics {
                contentDescription =
                    "Season ${episode.seasonNumber} episode ${episode.episodeNumber}, ${episode.title}" +
                        if (isCurrent) ", now playing" else ""
            }
            .clickable(
                enabled = enabled && !isCurrent,
                interactionSource = source,
                indication = null,
                role = Role.Button,
                onClick = { interaction.onInteract(); onClick() },
            ),
        verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(shape)
                .background(Color.White.copy(alpha = 0.10f))
                .border(
                    width = if (focused) 3.dp else if (isCurrent) 2.dp else 0.dp,
                    color = Color.White.copy(alpha = if (focused || isCurrent) 1f else 0f),
                    shape = shape,
                ),
            contentAlignment = Alignment.Center,
        ) {
            if (thumbnail != null) {
                AsyncImage(
                    model = thumbnail,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    onError = { imageFailed = true },
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                Text(
                    number,
                    color = Color.White.copy(alpha = 0.6f),
                    style = MaterialTheme.typography.titleMedium,
                )
            }

            if (isCurrent) {
                Text(
                    "NOW PLAYING",
                    color = Color.Black,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.White)
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }
        }

        Text(
            text = "$number · ${episode.title}",
            color = Color.White.copy(alpha = if (isCurrent) 1f else 0.72f),
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
