package app.vireo.player

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp

/** Everything the HUD can ask the player to do. Optional entries hide their control. */
class HudActions(
    val onBack: () -> Unit,
    val onPlayPause: () -> Unit,
    val onSeekBackward: () -> Unit,
    val onSeekForward: () -> Unit,
    val onSeekTo: (Long) -> Unit,
    val onPrevious: () -> Unit,
    val onNext: () -> Unit,
    /** Null = no preferences destination exists; the button is not shown. */
    val onOpenSettings: (() -> Unit)? = null,
    /** Series only; null hides episode selection (cards become display-only). */
    val onSelectEpisode: ((season: Int, episode: Int) -> Unit)? = null,
)

/** Shared auto-hide / focus plumbing owned by the overlay shell. */
class HudInteraction(
    val onInteract: () -> Unit,
    val onFocusChange: (Boolean) -> Unit,
)

/** Layout numbers chosen by the shell; Stage 3 makes these responsive. */
data class HudLayoutMetrics(
    val wide: Boolean,
    val horizontalPadding: Dp,
    val topPadding: Dp,
    val bottomPadding: Dp,
)

/** Circular, focusable HUD button with an unmistakable D-pad focus ring. */
@Composable
internal fun HudButton(
    onClick: () -> Unit,
    description: String,
    modifier: Modifier = Modifier,
    size: Dp = 46.dp,
    filled: Boolean = false,
    enabled: Boolean = true,
    onFocusChange: (Boolean) -> Unit = {},
    content: @Composable BoxScope.() -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val source = remember { MutableInteractionSource() }
    val ring = if (filled) Color(0xFF8E8E93) else Color.White

    Box(
        modifier = modifier
            .size(size)
            .scale(if (focused) 1.08f else 1f)
            .clip(CircleShape)
            .background(
                when {
                    filled -> Color.White
                    focused -> Color.White.copy(alpha = 0.22f)
                    else -> Color.Transparent
                }
            )
            .then(
                if (focused) Modifier.border(2.dp, ring, CircleShape) else Modifier
            )
            .alpha(if (enabled) 1f else 0.35f)
            .onFocusChanged {
                focused = it.isFocused
                onFocusChange(it.isFocused)
            }
            .semantics { contentDescription = description }
            .clickable(
                enabled = enabled,
                interactionSource = source,
                indication = null,
                role = Role.Button,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
        content = content,
    )
}

internal enum class HudGlyphKind { Play, Pause, Previous, Next }

/** Sharp vector glyphs (Material "extended" icons are not a dependency). */
@Composable
internal fun HudGlyph(
    kind: HudGlyphKind,
    tint: Color,
    glyphSize: Dp = 22.dp,
) {
    Canvas(modifier = Modifier.size(glyphSize)) {
        val w = this.size.width
        val h = this.size.height

        fun triangle(left: Float, right: Float, pointRight: Boolean) = Path().apply {
            if (pointRight) {
                moveTo(left, h * 0.14f)
                lineTo(right, h * 0.5f)
                lineTo(left, h * 0.86f)
            } else {
                moveTo(right, h * 0.14f)
                lineTo(left, h * 0.5f)
                lineTo(right, h * 0.86f)
            }
            close()
        }

        when (kind) {
            HudGlyphKind.Play -> drawPath(triangle(w * 0.2f, w * 0.9f, true), tint)

            HudGlyphKind.Pause -> {
                drawRect(tint, Offset(w * 0.18f, h * 0.12f), Size(w * 0.24f, h * 0.76f))
                drawRect(tint, Offset(w * 0.58f, h * 0.12f), Size(w * 0.24f, h * 0.76f))
            }

            HudGlyphKind.Previous -> {
                drawRect(tint, Offset(w * 0.1f, h * 0.14f), Size(w * 0.14f, h * 0.72f))
                drawPath(triangle(w * 0.3f, w * 0.92f, false), tint)
            }

            HudGlyphKind.Next -> {
                drawRect(tint, Offset(w * 0.76f, h * 0.14f), Size(w * 0.14f, h * 0.72f))
                drawPath(triangle(w * 0.08f, w * 0.7f, true), tint)
            }
        }
    }
}

/** Large primary play/pause button. */
@Composable
internal fun HudPlayPauseButton(
    isPlaying: Boolean,
    onClick: () -> Unit,
    size: Dp,
    onFocusChange: (Boolean) -> Unit,
) {
    HudButton(
        onClick = onClick,
        description = if (isPlaying) "Pause" else "Play",
        size = size,
        filled = true,
        onFocusChange = onFocusChange,
    ) {
        HudGlyph(
            kind = if (isPlaying) HudGlyphKind.Pause else HudGlyphKind.Play,
            tint = Color.Black,
            glyphSize = size * 0.42f,
        )
    }
}

@Composable
internal fun HudSeekLabel(text: String) {
    Text(
        text = text,
        color = Color.White,
        style = MaterialTheme.typography.labelLarge,
    )
}

/** Subtle top or bottom shading. The middle of the screen stays untouched. */
@Composable
internal fun BoxScope.HudEdgeScrim(top: Boolean, height: Dp, strength: Float = 0.78f) {
    Box(
        modifier = Modifier
            .align(if (top) Alignment.TopCenter else Alignment.BottomCenter)
            .fillMaxWidth()
            .height(height)
            .background(
                Brush.verticalGradient(
                    if (top) {
                        listOf(Color.Black.copy(alpha = strength * 0.8f), Color.Transparent)
                    } else {
                        listOf(Color.Transparent, Color.Black.copy(alpha = strength))
                    }
                )
            ),
    )
}

/**
 * Seek bar showing the real played and buffered ranges.
 *
 * Touch: tap or drag. D-pad: focus it, then left/right seek by [seekStepMs].
 * When [seekable] is false it is display-only and not focusable.
 */
@Composable
internal fun HudSeekBar(
    positionMs: Long,
    durationMs: Long,
    bufferedPositionMs: Long,
    seekable: Boolean,
    onSeekTo: (Long) -> Unit,
    interaction: HudInteraction,
    modifier: Modifier = Modifier,
    seekStepMs: Long = 10_000L,
) {
    var focused by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableStateOf<Float?>(null) }
    var widthPx by remember { mutableIntStateOf(0) }

    val fractions = progressFractions(positionMs, durationMs, bufferedPositionMs)
    val shown = dragFraction ?: fractions.played
    val interactive = seekable && durationMs > 0L

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(28.dp)
            .onSizeChanged { widthPx = it.width }
            .onFocusChanged {
                focused = it.isFocused
                interaction.onFocusChange(it.isFocused)
            }
            .then(
                if (interactive) {
                    Modifier
                        .onKeyEvent { event ->
                            if (event.type != KeyEventType.KeyDown) {
                                false
                            } else when (event.key) {
                                Key.DirectionLeft -> {
                                    interaction.onInteract()
                                    onSeekTo(steppedPosition(positionMs, durationMs, -seekStepMs))
                                    true
                                }
                                Key.DirectionRight -> {
                                    interaction.onInteract()
                                    onSeekTo(steppedPosition(positionMs, durationMs, seekStepMs))
                                    true
                                }
                                else -> false
                            }
                        }
                        .focusable()
                        .pointerInput(durationMs, widthPx) {
                            if (widthPx <= 0) return@pointerInput
                            detectTapGestures { offset ->
                                interaction.onInteract()
                                onSeekTo(positionForFraction(offset.x / widthPx, durationMs))
                            }
                        }
                        .pointerInput(durationMs, widthPx) {
                            if (widthPx <= 0) return@pointerInput
                            detectHorizontalDragGestures(
                                onDragStart = { start ->
                                    dragFraction = (start.x / widthPx).coerceIn(0f, 1f)
                                },
                                onHorizontalDrag = { change, _ ->
                                    change.consume()
                                    dragFraction = (change.position.x / widthPx).coerceIn(0f, 1f)
                                    interaction.onInteract()
                                },
                                onDragEnd = {
                                    dragFraction?.let {
                                        onSeekTo(positionForFraction(it, durationMs))
                                    }
                                    dragFraction = null
                                },
                                onDragCancel = { dragFraction = null },
                            )
                        }
                } else {
                    Modifier
                }
            ),
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(if (focused || dragFraction != null) 6.dp else 4.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Color.White.copy(alpha = 0.22f)),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fractions.buffered)
                    .background(Color.White.copy(alpha = 0.38f)),
            )
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(shown)
                    .background(Color.White),
            )
        }

        if (interactive) {
            val thumb = if (focused || dragFraction != null) 16.dp else 10.dp
            Box(
                modifier = Modifier
                    .offset { IntOffset((widthPx * shown).toInt() - thumb.roundToPx() / 2, 0) }
                    .size(thumb)
                    .clip(CircleShape)
                    .background(Color.White),
            )
        }
    }
}

/** Position - bar - duration row. Duration shows an en dash while unknown. */
@Composable
internal fun HudProgressRow(
    progress: PlayerProgressState,
    interaction: HudInteraction,
    onSeekTo: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            formatHudTime(progress.positionMs),
            color = Color.White.copy(alpha = 0.8f),
            style = MaterialTheme.typography.labelMedium,
        )
        HudSeekBar(
            positionMs = progress.positionMs,
            durationMs = progress.durationMs,
            bufferedPositionMs = progress.bufferedPositionMs,
            seekable = progress.isSeekable,
            onSeekTo = onSeekTo,
            interaction = interaction,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 12.dp),
        )
        Text(
            if (progress.durationMs > 0L) formatHudTime(progress.durationMs) else "–",
            color = Color.White.copy(alpha = 0.8f),
            style = MaterialTheme.typography.labelMedium,
        )
    }
}

/**
 * Transport row shared by the Movie and Series HUDs: previous / -10 / play-pause /
 * +10 / next, plus the preferences button when a destination exists. Previous and
 * next only appear when the queue really has them; seeking is disabled unless the
 * engine reports the current item as seekable.
 */
@Composable
internal fun HudTransportControls(
    hudState: PlayerHudState,
    progress: PlayerProgressState,
    actions: HudActions,
    interaction: HudInteraction,
    wide: Boolean,
) {
    val seekable = progress.isSeekable

    Box(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.align(Alignment.Center),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (hudState.hasPrevious) {
                HudButton(
                    onClick = { interaction.onInteract(); actions.onPrevious() },
                    description = "Previous",
                    onFocusChange = interaction.onFocusChange,
                ) { HudGlyph(HudGlyphKind.Previous, Color.White) }
            }

            HudButton(
                onClick = { interaction.onInteract(); actions.onSeekBackward() },
                description = "Back 10 seconds",
                enabled = seekable,
                onFocusChange = interaction.onFocusChange,
            ) { HudSeekLabel("−10") }

            HudPlayPauseButton(
                isPlaying = hudState.isPlaying,
                onClick = { interaction.onInteract(); actions.onPlayPause() },
                size = if (wide) 64.dp else 56.dp,
                onFocusChange = interaction.onFocusChange,
            )

            HudButton(
                onClick = { interaction.onInteract(); actions.onSeekForward() },
                description = "Forward 10 seconds",
                enabled = seekable,
                onFocusChange = interaction.onFocusChange,
            ) { HudSeekLabel("+10") }

            if (hudState.hasNext) {
                HudButton(
                    onClick = { interaction.onInteract(); actions.onNext() },
                    description = "Next",
                    onFocusChange = interaction.onFocusChange,
                ) { HudGlyph(HudGlyphKind.Next, Color.White) }
            }
        }

        actions.onOpenSettings?.let { openSettings ->
            HudButton(
                onClick = { interaction.onInteract(); openSettings() },
                description = "Player settings",
                modifier = Modifier.align(Alignment.CenterEnd),
                onFocusChange = interaction.onFocusChange,
            ) {
                Icon(Icons.Default.Settings, contentDescription = null, tint = Color.White)
            }
        }
    }
}
