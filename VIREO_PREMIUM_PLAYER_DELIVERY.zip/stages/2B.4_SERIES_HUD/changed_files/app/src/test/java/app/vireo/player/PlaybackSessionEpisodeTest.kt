package app.vireo.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PlaybackSessionEpisodeTest {

    private fun item(season: Int, episode: Int) = PlayItem(
        title = "S$season E$episode",
        url = "u-$season-$episode",
        contentType = "SERIES",
        seasonNumber = season,
        episodeNumber = episode,
    )

    private fun session(): PlaybackSession = PlaybackSession().apply {
        start(listOf(item(1, 2), item(1, 3), item(2, 1)), 0)
    }

    @Test
    fun `episode keys list exactly the queued episodes`() {
        assertEquals(
            setOf(EpisodeKey(1, 2), EpisodeKey(1, 3), EpisodeKey(2, 1)),
            session().episodeKeys(),
        )
    }

    @Test
    fun `items without numbering are not episode keys`() {
        val s = PlaybackSession().apply {
            start(listOf(PlayItem(title = "Movie", url = "u")), 0)
        }

        assertTrue(s.episodeKeys().isEmpty())
    }

    @Test
    fun `jump moves the queue and updates previous and next`() {
        val s = session()

        val target = s.jumpToEpisode(1, 3)

        assertEquals(1, target?.episodeNumber)
        assertEquals("u-1-3", s.current()?.url)
        assertTrue(s.hasPrevious())
        assertTrue(s.hasNext())
    }

    @Test
    fun `jump to a non queued episode changes nothing`() {
        val s = session()

        assertNull(s.jumpToEpisode(5, 5))
        assertEquals("u-1-2", s.current()?.url)
        assertFalse(s.hasPrevious())
    }

    @Test
    fun `jump resets the active alternative source`() {
        val withAlt = item(1, 2).copy(
            alternatives = listOf(PlaybackAlternative(2L, "x", "alt-url")),
        )
        val s = PlaybackSession().apply { start(listOf(withAlt, item(1, 3)), 0) }
        s.nextAlternative()
        assertEquals("alt-url", s.current()?.url)

        s.jumpToEpisode(1, 3)
        s.jumpToEpisode(1, 2)

        assertEquals("u-1-2", s.current()?.url)
    }
}
