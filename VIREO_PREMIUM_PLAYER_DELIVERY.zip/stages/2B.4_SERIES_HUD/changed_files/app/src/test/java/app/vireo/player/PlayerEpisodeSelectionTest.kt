package app.vireo.player

import app.vireo.data.ContentRepository
import app.vireo.data.EpgRepository
import app.vireo.data.LibraryRepository
import app.vireo.data.ProfileRepository
import app.vireo.data.ProfileSettingsRepository
import app.vireo.data.local.LiveChannelHistoryDao
import app.vireo.data.local.ProfileEntity
import app.vireo.data.local.ProfileSettingsEntity
import app.vireo.player.engine.Media3PlayerEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.mockito.Mockito

@OptIn(ExperimentalCoroutinesApi::class)
class PlayerEpisodeSelectionTest {

    private lateinit var session: PlaybackSession
    private lateinit var engine: Media3PlayerEngine
    private lateinit var profiles: ProfileRepository
    private lateinit var settings: ProfileSettingsRepository

    private val profile = ProfileEntity(id = 1L, name = "Test", kids = false)
    private val profileSettings = ProfileSettingsEntity(profileId = 1L)

    private fun episode(n: Int) = PlayItem(
        title = "Show · S1 E$n",
        url = "u$n",
        contentType = "SERIES",
        seasonNumber = 1,
        episodeNumber = n,
    )

    @Before
    fun setUp() {
        Dispatchers.setMain(StandardTestDispatcher())
        session = PlaybackSession()
        engine = Mockito.mock(Media3PlayerEngine::class.java)
        profiles = Mockito.mock(ProfileRepository::class.java)
        settings = Mockito.mock(ProfileSettingsRepository::class.java)
        Mockito.`when`(profiles.activeId).thenReturn(1L)
        Mockito.`when`(settings.observe(1L)).thenReturn(MutableStateFlow(profileSettings))
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    private suspend fun viewModel(scope: TestScope): PlayerViewModel {
        Mockito.`when`(profiles.get(1L)).thenReturn(profile)
        Mockito.`when`(settings.ensure(profileId = 1L, kidsMode = false))
            .thenReturn(profileSettings)

        return PlayerViewModel(
            session = session,
            media3PlayerEngine = engine,
            contentRepository = Mockito.mock(ContentRepository::class.java),
            library = Mockito.mock(LibraryRepository::class.java),
            profiles = profiles,
            epgRepository = Mockito.mock(EpgRepository::class.java),
            profileSettingsRepository = settings,
            liveChannelHistoryDao = Mockito.mock(LiveChannelHistoryDao::class.java),
            applicationScope = scope.backgroundScope,
        ).also { scope.advanceUntilIdle() }
    }

    @Test
    fun `selecting a queued episode switches the item and invalidates the old source`() = runTest {
        session.start(listOf(episode(1), episode(2), episode(3)), 0)
        val vm = viewModel(this)

        vm.playEpisode(1, 3, 0L, 0L)
        advanceUntilIdle()

        assertEquals("u3", vm.state.value.item?.url)
        Mockito.verify(engine).invalidateSource()
    }

    @Test
    fun `selecting the current or a non queued episode does nothing`() = runTest {
        session.start(listOf(episode(1), episode(2)), 0)
        val vm = viewModel(this)

        vm.playEpisode(1, 1, 0L, 0L)
        vm.playEpisode(7, 7, 0L, 0L)
        advanceUntilIdle()

        assertEquals("u1", vm.state.value.item?.url)
        Mockito.verify(engine, Mockito.never()).invalidateSource()
    }

    @Test
    fun `state exposes the queued episodes for the HUD`() = runTest {
        session.start(listOf(episode(1), episode(2)), 0)
        val vm = viewModel(this)

        assertTrue(EpisodeKey(1, 2) in vm.state.value.queuedEpisodes)
    }
}
