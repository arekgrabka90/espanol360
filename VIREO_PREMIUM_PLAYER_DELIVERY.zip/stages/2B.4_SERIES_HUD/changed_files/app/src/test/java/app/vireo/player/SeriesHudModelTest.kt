package app.vireo.player

import app.vireo.domain.model.EpgNowNext
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SeriesHudModelTest {

    private fun episode(season: Int, number: Int, desc: String? = null, thumb: String? = null) =
        PlaybackEpisode(
            title = "Ep $number",
            seasonNumber = season,
            episodeNumber = number,
            description = desc,
            thumbnailUrl = thumb,
        )

    private fun series(
        item: PlayItem,
        queued: Set<EpisodeKey> = emptySet(),
    ) = buildPlayerHudState(
        PlayerUiState(item = item, queuedEpisodes = queued),
        EpgNowNext(null, null),
        emptyList(),
    ).content as PlayerHudContent.Series

    private val episodes = listOf(episode(1, 1), episode(1, 2, "Two", "t2"), episode(1, 3))

    private fun item(season: Int? = 1, number: Int? = 2) = PlayItem(
        title = "Show · S1 E2 · Ep 2",
        url = "u",
        contentType = "SERIES",
        seriesTitle = "Show",
        seasonNumber = season,
        episodeNumber = number,
        episodes = episodes,
    )

    @Test
    fun `episode label is zero padded and absent without numbering`() {
        assertEquals("S01 · E02", seriesEpisodeLabel(1, 2))
        assertEquals("S12 · E103", seriesEpisodeLabel(12, 103))
        assertNull(seriesEpisodeLabel(null, 2))
        assertNull(seriesEpisodeLabel(1, null))
    }

    @Test
    fun `current episode index points at the playing episode`() {
        assertEquals(1, series(item()).currentEpisodeIndex())
        assertEquals(-1, series(item(season = 9, number = 9)).currentEpisodeIndex())
        assertEquals(-1, series(item(season = null, number = null)).currentEpisodeIndex())
    }

    @Test
    fun `episode cards represent the real episode list`() {
        val content = series(item())

        assertEquals(episodes, content.episodes)
        assertEquals("t2", content.currentEpisodeThumbnailUrl)
    }

    @Test
    fun `only queued episodes are selectable`() {
        val content = series(item(), queued = setOf(EpisodeKey(1, 1), EpisodeKey(1, 2)))

        assertTrue(content.canPlay(episodes[0]))
        assertFalse(content.canPlay(episodes[2]))
    }

    @Test
    fun `series metadata omits missing values`() {
        val content = series(item().copy(year = "2024", genre = null, rating = "8.0"))

        assertEquals(listOf("2024", "★ 8.0"), seriesMetadataParts(content))
        assertTrue(seriesMetadataParts(series(item())).isEmpty())
    }

    @Test
    fun `hud uses episode description before series description`() {
        val content = series(
            item().copy(description = "About the series", episodeDescription = null)
        )

        // Episode "Two" has a description in the list, so it wins over the series text.
        assertEquals("Two", content.displayDescription())
    }

    @Test
    fun `hud falls back to series description when the episode has none`() {
        val plain = listOf(episode(1, 1), episode(1, 2))
        val content = series(
            item().copy(description = "About the series", episodes = plain)
        )

        assertEquals("About the series", content.displayDescription())
    }
}
