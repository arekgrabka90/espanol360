# 2B.4_SERIES_HUD

Series HUD, episode thumbnail row, episode selection from the queue.

**Depends on:** 2B.3B_MOVIE_HUD

**Apply:** from the VIREO repo root `patch -p1 < patch.diff` (patches are sequential, in the order listed in IMPLEMENTATION_REPORT.md), or copy `changed_files/` over the repo (complete files; each stage's files are the state AFTER that stage).

**Files:** see FILES.txt. **Not executed:** build and tests (see TEST_REPORT.md).
