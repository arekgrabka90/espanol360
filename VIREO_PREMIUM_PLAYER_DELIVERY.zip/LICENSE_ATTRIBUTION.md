# LICENSE_ATTRIBUTION
No ARVIO source code was copied. ARVIO (Apache License 2.0 per the task description) was consulted only for ideas:
the infinite-transition pulse used for loading, and the existence of PlaybackParameters/TrackSelection/Cast/PiP implementations (audit only).
All new files are original work for VIREO. Existing VIREO headers/licences were not touched.
If code is later adapted from ARVIO, keep its notices and add the file to this list.
Note: the bundle contains no LICENSE file for either project; ARVIO/COPYRIGHT.md is a copyright-report notice, not a licence text. Confirm the Apache 2.0 text before any future copy.
