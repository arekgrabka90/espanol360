# VIREO Premium Player - Implementation Report

## 0. Honest status
- Code was written against the supplied bundle only. **Nothing was compiled and no test was executed**
  (no Gradle wrapper, no Kotlin compiler, no network in the authoring environment). See TEST_REPORT.md.
- Verified mechanically: stage patches apply in order on the exact baseline and reproduce the delivered tree
  byte-for-byte; brace/paren balance of every touched file; no FFmpeg, no secrets, no generated files.
- The bundle lacks ContentRepository, LibraryRepository, ui/theme, FocusableBox, Xtream domain models, Title.kt,
  TitleListViewModel.kt and the @Database class. See docs/MANUAL_CHANGES_REQUIRED.md.

## 1. Architecture findings (baseline)
1. PlayerHudOverlay drew a Coil AsyncImage (backdrop/poster, Crop) over 62-72% of the screen above the video; for LIVE it drew the channel icon that way. Removed.
2. PlayItem had no logo. TmdbDetail.logoUrl existed but neither PlayItem(...) construction in TmdbXtreamAvailabilityRepository passed it.
3. LIVE "logo" was posterUrl twice (HUD mapping and channel history, PlayerViewModel). Root cause upstream: Channel.toCatalogEntity() wrote stream_icon into posterUrl and Title had no logo field.
4. Series PlayItem.title is "Show - S1 E2 - Episode"; the HUD would show that as the series title -> seriesTitle/episodeTitle added.
5. Autoplay is correct and untouched: desiredPlayWhenReady = true; startPlayback pauses while resolving, plays after prepare only if the intent is still true. No second mechanism added.
6. Existing: PlayerProgressState (position/duration/buffered/isSeekable), ProfileSettingsRepository per-profile persistence, EPG now/next, recent LIVE history.
7. Auto-hide was a hard-coded 6 s; the slider ignored buffering.

## 2. Stages (apply in this order; each is a unified patch vs the previous state)
| # | Stage | Depends on |
|---|---|---|
| 1 | 2B.3A_PLAYER_FOUNDATION | baseline |
| 2 | 2B.3A_LIVE_LOGO_PERSISTENCE | 1 + manual hunks |
| 3 | 2B.3B_MOVIE_HUD | 1 |
| 4 | 2B.4_SERIES_HUD | 3 |
| 5 | 2B.5_LIVE_HUD | 4 (2 for real channel logos) |
| 6 | STAGE_3_RESPONSIVENESS | 5 and 2 (migration file) |
The LIVE persistence work is split out of 2B.3A on purpose: it touches Room and cannot be compiled without files that were not supplied.

## 3. Key decisions
- Logo XOR title: `HudBrand` sealed type (Logo/Title/None); the title inside Logo is only the load-failure fallback. Posters/backdrops are never candidates.
- Buffering (movie/series): subtle pulsing TMDB logo (infiniteTransition, Reverse tween, scale 1.0-1.08, alpha .62-1), ContentScale.Fit, no scrim. No logo -> small spinner. LIVE -> small spinner. No "BUFFERING" text anywhere.
- HUD is a transparent overlay; only soft top/bottom gradients. Middle of the picture is never covered; a paused frame stays visible.
- Series: current-episode description wins; series description only as fallback (blank counts as missing). Episode cards are 16:9 (Crop, never stretched), current one outlined + "NOW PLAYING". Selecting an episode needs PlaybackSession.jumpToEpisode / PlayerViewModel.playEpisode (small, justified dependency); only episodes present in the queue are selectable (the queue omits watched episodes when watch history exists).
- LIVE: two independent bars (small one in the info block, wide one below it). Channel name appears in the info block only when the left area shows a logo. Seek buttons only if the engine reports a seekable stream with a window; prev/next = channel navigation only if the queue has them. **Verified quality info is intentionally absent**: VIREO has no verified source for resolution/codec yet.
- Tiles: TV Guide / History only with a real destination; recent channels come from stored history (newest first, current excluded) and are clickable only if a handler is supplied.
- Stage 3: pure HudLayoutSpec (PhonePortrait/PhoneLandscape/Tablet/Tv), HudAutoHidePolicy (3/5/8/10/Off, **default 8 s**, never hides with focus or open panel, optional keep-visible-when-paused), key logic (media keys always act; D-pad wakes hidden HUD and focus lands on play/pause; tap layer takes focus when hidden), double-tap left/right seek (configurable, default off on TV), touch lock (long-press unlocks), preferences panel persisted per profile (4 new profile_settings columns, sanitized, migration provided).
- Default auto-hide 8 s differs from the 5 s mentioned in the planning message: longer is the conservative choice for remote users.

## 4. Compatibility
Media3 1.11.1, Compose BOM 2024.06 / Coil 2.6, material-icons-core only (play/pause/skip glyphs drawn on Canvas). New PlayItem/HUD fields have defaults, so all existing constructors and tests compile. PlayerHudOverlay/PlayerScreen gained only optional parameters. No dependency, SDK, signing, CI or package changes.

## 5. Feature audit (not implemented unless stated)
| Feature | VIREO now | ARVIO reference | Notes |
|---|---|---|---|
| Audio track selection | preferred language only (setPreferredAudioLanguage); no track list | TrackSelectionParameters in PlayerScreen | feasible on Media3 1.11.1; needs engine API + UI |
| Subtitle selection / external subs | no (only enable + size settings) | SubtitleConfiguration in PlayerViewModel/Screen | feasible; needs source plumbing |
| Subtitle appearance / sync | size setting only; no SubtitleView styling | CaptionStyleCompat/SubtitleView | feasible |
| Audio offset | no | AudioOffset in PlayerEngine | ARVIO uses custom engine code; verify against 1.11.1 before copying |
| Source selection | automatic failover via PlaybackAlternative; no picker | provided-source lookup | picker UI only |
| Aspect ratio modes | no | resizeMode in PlayerEngine | simple PlayerView.resizeMode |
| Playback speed | no | PlaybackParameters | trivial, not for LIVE |
| Seek preview thumbnails | no | none found | needs sprite/thumbnail source |
| Resume position | yes (library.resumePosition / saveProgress) | - | existing, untouched |
| Next episode / countdown | next() exists; autoplayNext setting exists; no countdown UI | - | UI + timer only |
| Skip intro/outro | no | none | needs chapter/marker data |
| Picture-in-Picture | no | enterPictureInPictureMode | Activity-level change |
| Google Cast | no | CastManager (+ cast deps) | new dependencies; deferred |
| Technical diagnostics | no | - | should come from real Format data |
Not added: FFmpeg or any engine change.

## 6. Known limitations / outstanding
- Not compiled/tested (see above). Treat first Gradle build as the real review.
- PlayerScreen keeps its existing landscape lock, so PhonePortrait layout is only reachable if that lock is relaxed.
- Progress is passed by value to the HUD, so HUD content recomposes with each progress tick (same as before); isolating it behind lambdas is a follow-up.
- TV Guide/History destinations and recent-channel switching need NavHost wiring (not in bundle).
- Metadata-visibility options exist as `MovieHudMetadata` (all on); no UI/persistence for them.
- Series row cards for non-queued (watched) episodes are shown dimmed and not selectable.
- Visual verification (focus rings, spacing, two LIVE bars, no artwork over video) needs a device/emulator.
